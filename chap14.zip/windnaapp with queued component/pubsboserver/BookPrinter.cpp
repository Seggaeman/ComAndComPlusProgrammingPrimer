// BookPrinter.cpp : Implementation of CBookPrinter
#include "stdafx.h"
#include "Pubsboserver.h"
#include "BookPrinter.h"
#include "getpathfromreg.h"
#include <stdio.h>
/////////////////////////////////////////////////////////////////////////////
// CBookPrinter

STDMETHODIMP CBookPrinter::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IBookPrinter
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CBookPrinter::PrintCopies(BSTR titleID, BSTR title, short numCopies, DATE needBy, BSTR specialInstructions, DATE sentWhen)
{
	HRESULT hRetval;		
	_bstr_t bDescription;
	char strFileName[255];
	_bstr_t strFullPath;
	hRetval=S_OK;
	SYSTEMTIME dtSysDateTime;
	MSXML::IXMLDOMDocumentPtr pDoc;
	MSXML::IXMLDOMElementPtr pRootElement;
	IContextState *pContextState;
	
	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContextState);
	if (SUCCEEDED(hRetval))
	{
		try
		{
			::Sleep(5000);
			pDoc.CreateInstance( __uuidof(MSXML::DOMDocument));
			pRootElement=pDoc->createElement("PrintJobs");
			pDoc->documentElement=pRootElement;
			GetLocalTime(&dtSysDateTime);
			AddPrintJob(pDoc,pRootElement,titleID,title,numCopies,needBy,
				specialInstructions,sentWhen);									
			sprintf(strFileName,"printcopies%d%d%d_%d%d%d.xml",
				dtSysDateTime.wMonth,dtSysDateTime.wDay,
				dtSysDateTime.wYear,dtSysDateTime.wHour,
				dtSysDateTime.wMinute,dtSysDateTime.wSecond);
			
			strFullPath=GetPathFromReg(_T("OutputDir"))+_bstr_t("\\") + strFileName;
			pDoc->save(strFullPath);
			
		}
		catch ( _com_error err)
		{
			hRetval=err.Error();
			bDescription=err.Description();
		}
	}
	else
		bDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";

	if (NULL != pContextState)
	{
		if (SUCCEEDED(hRetval))
			pContextState->SetMyTransactionVote(TxCommit);
		else
			pContextState->SetMyTransactionVote(TxAbort);
		
		pContextState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContextState->Release();
	}

	if (SUCCEEDED(hRetval))
		return S_OK;
	else
		return Error((LPOLESTR)bDescription,IID_IBook,hRetval);

}

void CBookPrinter::AddPrintJob(IXMLDOMDocumentPtr pDoc, IXMLDOMElementPtr pRootElement, BSTR titleID, BSTR title, long numCopies, DATE needBy, BSTR specialInstructions, DATE sentDate)
{
	IXMLDOMElementPtr pElement;
	_bstr_t elementName;
	_bstr_t elementValue;
	_variant_t lngNumCopies(numCopies,VT_I4);
	_variant_t dtSentDateTime(sentDate,VT_DATE);
	_variant_t vNeedBy(needBy,VT_DATE);

	elementName="PrintJob";
	pElement=pDoc->createElement(elementName);		
	pRootElement->appendChild(pElement);
		
	dtSentDateTime.ChangeType(VT_BSTR,NULL);
	elementName="SentDateTime";
	elementValue=dtSentDateTime;
	AddPrintJobElement(pDoc,pElement,elementName,elementValue);

	elementName="TitleID";
	elementValue=titleID;
	AddPrintJobElement(pDoc,pElement,elementName,elementValue);
	
	elementName="Title";
	elementValue=title;
	AddPrintJobElement(pDoc,pElement,elementName,elementValue);
	
	lngNumCopies.ChangeType(VT_BSTR,NULL);
	elementName="NumCopies";
	elementValue=lngNumCopies;
	AddPrintJobElement(pDoc,pElement,elementName,elementValue);
 	
	vNeedBy.ChangeType(VT_BSTR,NULL);
	elementName="NeedBy";
	elementValue=vNeedBy;
	AddPrintJobElement(pDoc,pElement,elementName,elementValue);

	elementName="SpecialInstructions";
	elementValue=specialInstructions;
	AddPrintJobElement(pDoc,pElement,elementName,elementValue);
}

void CBookPrinter::AddPrintJobElement(IXMLDOMDocumentPtr pDoc, IXMLDOMElementPtr pPrintJobRootElement, BSTR elementName, BSTR elementValue)
{
 	IXMLDOMElementPtr pChildElement;	
 	pChildElement=pDoc->createElement(elementName);
 	pChildElement->text=elementValue;
 	pPrintJobRootElement->appendChild(pChildElement);
}
