#ifndef GETPATHFROMREG_H
#define GETPATHFROMREG_H
_bstr_t GetPathFromReg(LPCTSTR lpszKeyName);
#endif