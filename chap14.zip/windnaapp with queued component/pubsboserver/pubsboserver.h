
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Mon May 01 01:20:30 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter14\windnaapp with queued component\pubsboserver\pubsboserver.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __pubsboserver_h__
#define __pubsboserver_h__

/* Forward Declarations */ 

#ifndef __IBook_FWD_DEFINED__
#define __IBook_FWD_DEFINED__
typedef interface IBook IBook;
#endif 	/* __IBook_FWD_DEFINED__ */


#ifndef __IAuthor_FWD_DEFINED__
#define __IAuthor_FWD_DEFINED__
typedef interface IAuthor IAuthor;
#endif 	/* __IAuthor_FWD_DEFINED__ */


#ifndef __IPublisher_FWD_DEFINED__
#define __IPublisher_FWD_DEFINED__
typedef interface IPublisher IPublisher;
#endif 	/* __IPublisher_FWD_DEFINED__ */


#ifndef __IBookPrinter_FWD_DEFINED__
#define __IBookPrinter_FWD_DEFINED__
typedef interface IBookPrinter IBookPrinter;
#endif 	/* __IBookPrinter_FWD_DEFINED__ */


#ifndef __Book_FWD_DEFINED__
#define __Book_FWD_DEFINED__

#ifdef __cplusplus
typedef class Book Book;
#else
typedef struct Book Book;
#endif /* __cplusplus */

#endif 	/* __Book_FWD_DEFINED__ */


#ifndef __Author_FWD_DEFINED__
#define __Author_FWD_DEFINED__

#ifdef __cplusplus
typedef class Author Author;
#else
typedef struct Author Author;
#endif /* __cplusplus */

#endif 	/* __Author_FWD_DEFINED__ */


#ifndef __Publisher_FWD_DEFINED__
#define __Publisher_FWD_DEFINED__

#ifdef __cplusplus
typedef class Publisher Publisher;
#else
typedef struct Publisher Publisher;
#endif /* __cplusplus */

#endif 	/* __Publisher_FWD_DEFINED__ */


#ifndef __BookPrinter_FWD_DEFINED__
#define __BookPrinter_FWD_DEFINED__

#ifdef __cplusplus
typedef class BookPrinter BookPrinter;
#else
typedef struct BookPrinter BookPrinter;
#endif /* __cplusplus */

#endif 	/* __BookPrinter_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __PUBSBOSERVERLib_LIBRARY_DEFINED__
#define __PUBSBOSERVERLib_LIBRARY_DEFINED__

/* library PUBSBOSERVERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_PUBSBOSERVERLib;

#ifndef __IBook_INTERFACE_DEFINED__
#define __IBook_INTERFACE_DEFINED__

/* interface IBook */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IBook;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4A2834F0-B825-438B-A8E2-0F5E49732E5D")
    IBook : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RetrieveByKeyword( 
            /* [in] */ BSTR keyword,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RetrieveByID( 
            /* [in] */ BSTR id,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetNewBookRecordSet( 
            /* [in] */ short numRecords,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetExistingBookRecordSet( 
            /* [in] */ BSTR criterion,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteBook( 
            /* [in] */ BSTR id) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UpdateBooks( 
            /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rsBookInfo,
            /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rsAuthorInfo) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IBookVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IBook __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IBook __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IBook __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IBook __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IBook __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IBook __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IBook __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RetrieveByKeyword )( 
            IBook __RPC_FAR * This,
            /* [in] */ BSTR keyword,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RetrieveByID )( 
            IBook __RPC_FAR * This,
            /* [in] */ BSTR id,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetNewBookRecordSet )( 
            IBook __RPC_FAR * This,
            /* [in] */ short numRecords,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetExistingBookRecordSet )( 
            IBook __RPC_FAR * This,
            /* [in] */ BSTR criterion,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteBook )( 
            IBook __RPC_FAR * This,
            /* [in] */ BSTR id);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UpdateBooks )( 
            IBook __RPC_FAR * This,
            /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rsBookInfo,
            /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rsAuthorInfo);
        
        END_INTERFACE
    } IBookVtbl;

    interface IBook
    {
        CONST_VTBL struct IBookVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBook_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBook_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBook_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IBook_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IBook_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IBook_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IBook_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IBook_RetrieveByKeyword(This,keyword,rs)	\
    (This)->lpVtbl -> RetrieveByKeyword(This,keyword,rs)

#define IBook_RetrieveByID(This,id,rs)	\
    (This)->lpVtbl -> RetrieveByID(This,id,rs)

#define IBook_GetNewBookRecordSet(This,numRecords,rs)	\
    (This)->lpVtbl -> GetNewBookRecordSet(This,numRecords,rs)

#define IBook_GetExistingBookRecordSet(This,criterion,rs)	\
    (This)->lpVtbl -> GetExistingBookRecordSet(This,criterion,rs)

#define IBook_DeleteBook(This,id)	\
    (This)->lpVtbl -> DeleteBook(This,id)

#define IBook_UpdateBooks(This,rsBookInfo,rsAuthorInfo)	\
    (This)->lpVtbl -> UpdateBooks(This,rsBookInfo,rsAuthorInfo)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IBook_RetrieveByKeyword_Proxy( 
    IBook __RPC_FAR * This,
    /* [in] */ BSTR keyword,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IBook_RetrieveByKeyword_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IBook_RetrieveByID_Proxy( 
    IBook __RPC_FAR * This,
    /* [in] */ BSTR id,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IBook_RetrieveByID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IBook_GetNewBookRecordSet_Proxy( 
    IBook __RPC_FAR * This,
    /* [in] */ short numRecords,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IBook_GetNewBookRecordSet_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IBook_GetExistingBookRecordSet_Proxy( 
    IBook __RPC_FAR * This,
    /* [in] */ BSTR criterion,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IBook_GetExistingBookRecordSet_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IBook_DeleteBook_Proxy( 
    IBook __RPC_FAR * This,
    /* [in] */ BSTR id);


void __RPC_STUB IBook_DeleteBook_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IBook_UpdateBooks_Proxy( 
    IBook __RPC_FAR * This,
    /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rsBookInfo,
    /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rsAuthorInfo);


void __RPC_STUB IBook_UpdateBooks_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IBook_INTERFACE_DEFINED__ */


#ifndef __IAuthor_INTERFACE_DEFINED__
#define __IAuthor_INTERFACE_DEFINED__

/* interface IAuthor */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAuthor;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("360A71F7-37A3-46DD-9171-236A4BC887FA")
    IAuthor : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE UpdateAuthorsForTitle( 
            /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAuthors( 
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAuthorsForTitle( 
            /* [in] */ BSTR titleID,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetNewTitleAuthorRecordSet( 
            /* [in] */ short numRecords,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAuthorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IAuthor __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IAuthor __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IAuthor __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IAuthor __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IAuthor __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IAuthor __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IAuthor __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UpdateAuthorsForTitle )( 
            IAuthor __RPC_FAR * This,
            /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAuthors )( 
            IAuthor __RPC_FAR * This,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAuthorsForTitle )( 
            IAuthor __RPC_FAR * This,
            /* [in] */ BSTR titleID,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetNewTitleAuthorRecordSet )( 
            IAuthor __RPC_FAR * This,
            /* [in] */ short numRecords,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        END_INTERFACE
    } IAuthorVtbl;

    interface IAuthor
    {
        CONST_VTBL struct IAuthorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAuthor_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAuthor_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAuthor_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAuthor_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAuthor_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAuthor_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAuthor_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAuthor_UpdateAuthorsForTitle(This,rs)	\
    (This)->lpVtbl -> UpdateAuthorsForTitle(This,rs)

#define IAuthor_GetAuthors(This,rs)	\
    (This)->lpVtbl -> GetAuthors(This,rs)

#define IAuthor_GetAuthorsForTitle(This,titleID,rs)	\
    (This)->lpVtbl -> GetAuthorsForTitle(This,titleID,rs)

#define IAuthor_GetNewTitleAuthorRecordSet(This,numRecords,rs)	\
    (This)->lpVtbl -> GetNewTitleAuthorRecordSet(This,numRecords,rs)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAuthor_UpdateAuthorsForTitle_Proxy( 
    IAuthor __RPC_FAR * This,
    /* [in] */ /* external definition not present */ _Recordset __RPC_FAR *rs);


void __RPC_STUB IAuthor_UpdateAuthorsForTitle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAuthor_GetAuthors_Proxy( 
    IAuthor __RPC_FAR * This,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IAuthor_GetAuthors_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAuthor_GetAuthorsForTitle_Proxy( 
    IAuthor __RPC_FAR * This,
    /* [in] */ BSTR titleID,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IAuthor_GetAuthorsForTitle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAuthor_GetNewTitleAuthorRecordSet_Proxy( 
    IAuthor __RPC_FAR * This,
    /* [in] */ short numRecords,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IAuthor_GetNewTitleAuthorRecordSet_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAuthor_INTERFACE_DEFINED__ */


#ifndef __IPublisher_INTERFACE_DEFINED__
#define __IPublisher_INTERFACE_DEFINED__

/* interface IPublisher */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPublisher;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5E3070A9-0C5B-48DD-BDF6-D441C4996116")
    IPublisher : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPublishers( 
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPublisherVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPublisher __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPublisher __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPublisher __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPublisher __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPublisher __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPublisher __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPublisher __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPublishers )( 
            IPublisher __RPC_FAR * This,
            /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);
        
        END_INTERFACE
    } IPublisherVtbl;

    interface IPublisher
    {
        CONST_VTBL struct IPublisherVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPublisher_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPublisher_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPublisher_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPublisher_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPublisher_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPublisher_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPublisher_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPublisher_GetPublishers(This,rs)	\
    (This)->lpVtbl -> GetPublishers(This,rs)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPublisher_GetPublishers_Proxy( 
    IPublisher __RPC_FAR * This,
    /* [retval][out] */ /* external definition not present */ _Recordset __RPC_FAR *__RPC_FAR *rs);


void __RPC_STUB IPublisher_GetPublishers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPublisher_INTERFACE_DEFINED__ */


#ifndef __IBookPrinter_INTERFACE_DEFINED__
#define __IBookPrinter_INTERFACE_DEFINED__

/* interface IBookPrinter */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IBookPrinter;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("CEE2ECDE-BC67-46AC-9079-1DDD33E0808D")
    IBookPrinter : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE PrintCopies( 
            /* [in] */ BSTR titleID,
            /* [in] */ BSTR title,
            /* [in] */ short numCopies,
            /* [in] */ DATE needBy,
            /* [in] */ BSTR specialInstructions,
            /* [in] */ DATE sentWhen) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IBookPrinterVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IBookPrinter __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IBookPrinter __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IBookPrinter __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IBookPrinter __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IBookPrinter __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IBookPrinter __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IBookPrinter __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PrintCopies )( 
            IBookPrinter __RPC_FAR * This,
            /* [in] */ BSTR titleID,
            /* [in] */ BSTR title,
            /* [in] */ short numCopies,
            /* [in] */ DATE needBy,
            /* [in] */ BSTR specialInstructions,
            /* [in] */ DATE sentWhen);
        
        END_INTERFACE
    } IBookPrinterVtbl;

    interface IBookPrinter
    {
        CONST_VTBL struct IBookPrinterVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBookPrinter_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBookPrinter_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBookPrinter_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IBookPrinter_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IBookPrinter_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IBookPrinter_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IBookPrinter_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IBookPrinter_PrintCopies(This,titleID,title,numCopies,needBy,specialInstructions,sentWhen)	\
    (This)->lpVtbl -> PrintCopies(This,titleID,title,numCopies,needBy,specialInstructions,sentWhen)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IBookPrinter_PrintCopies_Proxy( 
    IBookPrinter __RPC_FAR * This,
    /* [in] */ BSTR titleID,
    /* [in] */ BSTR title,
    /* [in] */ short numCopies,
    /* [in] */ DATE needBy,
    /* [in] */ BSTR specialInstructions,
    /* [in] */ DATE sentWhen);


void __RPC_STUB IBookPrinter_PrintCopies_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IBookPrinter_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_Book;

#ifdef __cplusplus

class DECLSPEC_UUID("4C4F35F1-4206-464B-BE53-1C426C821DA9")
Book;
#endif

EXTERN_C const CLSID CLSID_Author;

#ifdef __cplusplus

class DECLSPEC_UUID("CF5C98BE-AE8B-4120-A7E4-84AB8C37E46B")
Author;
#endif

EXTERN_C const CLSID CLSID_Publisher;

#ifdef __cplusplus

class DECLSPEC_UUID("A746E063-4E76-4F6F-AD1E-42BA1F99FF2C")
Publisher;
#endif

EXTERN_C const CLSID CLSID_BookPrinter;

#ifdef __cplusplus

class DECLSPEC_UUID("E3D365E3-D7ED-4913-91BF-E33A3A898844")
BookPrinter;
#endif
#endif /* __PUBSBOSERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


