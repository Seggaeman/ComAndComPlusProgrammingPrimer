// Book.cpp : Implementation of CBook
#include "stdafx.h"
#include "Pubsboserver.h"
#include "Book.h"
#include "errorcodes.h"
const E_CONFIGURATION=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+108);
/////////////////////////////////////////////////////////////////////////////
// CBook

STDMETHODIMP CBook::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IBook
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CBook::RetrieveByKeyword(BSTR keyword, _Recordset **rs)
{
	_bstr_t strDescription;
	HRESULT hRetval;	
	_ConnectionPtr pConn;
	_RecordsetPtr pRS;
	_CommandPtr pCmd;
	_ParameterPtr pParam;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	_bstr_t processedKeyword;
	IContextState *pContxState=NULL;
	
	if (0==mConnectionString.length())
	{
		hRetval=E_CONFIGURATION;
		strDescription=L"You must configure a connection string";
		goto exit_cleanup;	
	}
	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		processedKeyword="%" + bstr_t(keyword) +"%";
		_bstr_t sql("SELECT titles.title_id, titles.title,"\
			" authors.au_lname, authors.au_fname,"\
			" titles.type, titles.price"\
			" FROM authors"\
			" INNER JOIN titleauthor ON authors.au_id=titleauthor.au_id"\
			" INNER JOIN titles ON titleauthor.title_id=titles.title_id"\
			" WHERE (titleauthor.au_ord = 1) AND (titles.title LIKE ?)"\
			" ORDER BY titles.title");
		
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString,"","",-1);
			pCmd.CreateInstance( __uuidof(Command));
			pCmd->CommandType=adCmdText;
			pCmd->CommandText=sql;
			pCmd->ActiveConnection=pConn;
			pParam=pCmd->CreateParameter(_bstr_t(L""),adVarChar,
				adParamInput,80,processedKeyword);
			pCmd->Parameters->Append(pParam);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pRS->Open(pCmd.GetInterfacePtr(),blank,adOpenStatic,
				adLockBatchOptimistic,-1);
			pRS->AddRef();
			*rs=pRS;
			pRS->PutRefActiveConnection(NULL);
		}
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else 
	{		
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code	
exit_cleanup:
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IBook,hRetval);
}

STDMETHODIMP CBook::RetrieveByID(BSTR id, _Recordset **rs)
{
	HRESULT hRetval;
	_bstr_t strDescription;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	_bstr_t sql("SELECT titles.title_id, titles.title, titles.price,"\
	   " titles.advance, titles.royalty, titles.ytd_sales, "\
	   " titles.notes, titles.type,titles.pubdate, titles.pub_id,"\
	   " publishers.pub_name, authors.au_id, authors.au_lname,"\
	   " authors.au_fname"\
	   " FROM titles "\
	   " INNER JOIN publishers ON titles.pub_id=publishers.pub_id "\
	   " INNER JOIN titleauthor ON titles.title_id=titleauthor.title_id"\
	   " INNER JOIN authors ON titleauthor.au_id=authors.au_id"\
	   " WHERE (titleauthor.au_ord = 1) AND (titles.title_id = ?)");
	_ConnectionPtr pConn;
	_RecordsetPtr pRS;
	_CommandPtr pCmd;
	_ParameterPtr pParam;	
	IContextState *pContxState;

	hRetval=CoGetObjectContext(IID_IContextState,(void**)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString, "", "",-1);
			pCmd.CreateInstance( __uuidof(Command));
			pCmd->CommandType=adCmdText;
			pCmd->CommandText=sql;
			pCmd->ActiveConnection=pConn;
			pParam=pCmd->CreateParameter(_bstr_t(L""),adVarChar,
				adParamInput,6,id);
			pCmd->Parameters->Append(pParam);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pRS->Open(pCmd.GetInterfacePtr(),blank,adOpenStatic,
				adLockBatchOptimistic,-1);
			pRS->AddRef();
			*rs=pRS;
			pRS->PutRefActiveConnection(NULL);
		}
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else 
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IBook,hRetval);
}

STDMETHODIMP CBook::GetNewBookRecordSet(short numRecords, _Recordset **rs)
{
	_bstr_t strDescription;
	HRESULT hRetval;
	
	_ConnectionPtr pConn;
	_RecordsetPtr pRS;
	_CommandPtr pCmd;
	_ParameterPtr pParam;
	int i;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	IContextState *pContxState;

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
			bstr_t sql("SELECT titles.title_id, titles.title,"\
				" titles.price, titles.advance, titles.royalty,"\
				" titles.ytd_sales, titles.notes, titles.type,"\
				" titles.pubdate,titles.pub_id"\
				" FROM titles"\
				" WHERE (1 = 2)");		
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString,"","",-1);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pRS->Open(sql,pConn.GetInterfacePtr(),adOpenStatic,
				adLockBatchOptimistic,-1);
			pRS->AddRef();
			for (i=0;i<numRecords;i++)
				pRS->AddNew();
			pRS->MoveFirst();
			*rs=pRS;		
			pRS->PutRefActiveConnection(NULL);			
		}
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else 
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IBook,hRetval);
}

STDMETHODIMP CBook::GetExistingBookRecordSet(BSTR criterion, _Recordset **rs)
{
	_bstr_t strDescription;
	HRESULT hRetval;
	
	_ConnectionPtr pConn;
	_RecordsetPtr pRS;
	_CommandPtr pCmd;
	_ParameterPtr pParam;

	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	IContextState *pContxState;

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		bstr_t sql("SELECT titles.title_id, titles.title, titles.price,"\
			" titles.advance, titles.royalty, titles.ytd_sales,"\
			" titles.notes, titles.type, titles.pubdate, titles.pub_id"\
			" FROM titles WHERE ");
		sql=sql+criterion;
		
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString,"","",-1);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pRS->Open(sql,pConn.GetInterfacePtr(),adOpenStatic,
				adLockBatchOptimistic,-1);
			pRS->AddRef();
			*rs=pRS;	
			pRS->PutRefActiveConnection(NULL);
		}
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else 
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IBook,hRetval);
}

STDMETHODIMP CBook::DeleteBook(BSTR id)
{
	_bstr_t strDescription;
	HRESULT hRetval;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	_bstr_t sqlDeleteTitleAuthor("DELETE FROM titleauthor"\
		" WHERE title_id = ?");
	_bstr_t sqlDeleteTitle("DELETE FROM titles"\
		" WHERE titles.title_id = ?");
	_RecordsetPtr pRS;
	_CommandPtr pCmd;
	_ConnectionPtr pConn;
	_ParameterPtr pParam;
	IContextState *pContxState;
	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString,"","",-1);
			pCmd.CreateInstance( __uuidof(Command));
			pCmd->CommandType=adCmdText;
			pCmd->CommandText=sqlDeleteTitleAuthor;
			pCmd->ActiveConnection=pConn;
			pParam=pCmd->CreateParameter(_bstr_t(""),adVarChar,
				adParamInput,6,id);
			pCmd->Parameters->Append(pParam);
			pCmd->Execute(&blank,&blank,-1);
			pCmd->CommandText=sqlDeleteTitle;
			pCmd->Execute(&blank,&blank,-1);
			hRetval=S_OK;
		}
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error(); 
		}
	}
	else 
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IBook,hRetval);
}

STDMETHODIMP CBook::UpdateBooks(_Recordset *rsBookInfo, _Recordset *rsAuthorInfo)
{
	HRESULT hRetval;
	_bstr_t strDescription;
	_ConnectionPtr pConn;
	_RecordsetPtr pRS;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	_bstr_t strMsg;
	CComPtr<IAuthor> authorPtr;
	BSTR strError;	
	IErrorInfo* pei;
	IContextState *pContxState;

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		if (NULL != rsBookInfo)
		{	
			try
			{						
				pRS=rsBookInfo;
				pConn.CreateInstance( __uuidof(Connection));
				pConn->Open(mConnectionString, "", "",-1);
				pRS->PutRefActiveConnection(pConn);
				pRS->UpdateBatch(adAffectAll);
				pRS->Filter=_variant_t((short)adFilterConflictingRecords);
				if (pRS->RecordCount > 0) 
				{
					strMsg="The following books could not be updated: ";
					while (pRS->adoEOF != VARIANT_TRUE)
					{
						strMsg+=_bstr_t(
							pRS->Fields->Item["title_id"]->Value)+" ";
						pRS->MoveNext();
					}
					strDescription=strMsg;
					hRetval=E_CONFLICTS_FOUND;
				}
			}
			catch ( _com_error err)
			{
				strDescription=err.Description();
				hRetval=err.Error();
			}
		}
		else
			hRetval=S_OK;

		if (NULL != rsAuthorInfo && S_OK == hRetval)
		{
			hRetval=authorPtr.CoCreateInstance(__uuidof(Author));
			if (SUCCEEDED(hRetval))
			{
				hRetval=authorPtr->UpdateAuthorsForTitle(rsAuthorInfo);
				if (FAILED(hRetval))
				{
					if (SUCCEEDED(GetErrorInfo(0, &pei)))
						if (pei)
							if (SUCCEEDED(pei->GetDescription(&strError)))
								pei->Release();
					strDescription=strError;
				}
			}
		}
	}
	else
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	

	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IBook,hRetval);
}
