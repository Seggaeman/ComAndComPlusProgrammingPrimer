// Author.cpp : Implementation of CAuthor
#include "stdafx.h"
#include "Pubsboserver.h"
#include "Author.h"
#include "errorcodes.h"
/////////////////////////////////////////////////////////////////////////////
// CAuthor

STDMETHODIMP CAuthor::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IAuthor
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CAuthor::UpdateAuthorsForTitle(_Recordset *rs)
{
	_bstr_t strDescription;
	HRESULT hRetval;
	_ConnectionPtr pConn;
	_RecordsetPtr pRS;
	_CommandPtr pCmd;
	_bstr_t strTitleInClause;
	_bstr_t strMsg;
	_bstr_t sql("DELETE FROM titleauthor WHERE title_id IN ");
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	IContextState *pContxState;
	short authorOrder;	
	short intAuthorOrder=1;

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);	
	if (SUCCEEDED(hRetval))
	{		
		if (NULL != rs && (rs->GetRecordCount() > 0))
		{
			try
			{
				pRS=rs;							
				pConn.CreateInstance( __uuidof(Connection));
				pConn->Open(mConnectionString, "", "",-1);
				pCmd.CreateInstance( __uuidof(Command));
				pCmd->CommandType=adCmdText;
				strTitleInClause=GetInClause(rs,"title_id");
				sql+=strTitleInClause;
				pCmd->CommandText=sql;
				pCmd->ActiveConnection=pConn;
				pCmd->Execute(&blank,&blank,-1);
				pRS->PutRefActiveConnection(pConn);
				pRS->MoveFirst();
				authorOrder=1;
				while (pRS->adoEOF != VARIANT_TRUE)
				{
					pRS->Fields->Item["au_ord"]->Value=
						_variant_t(authorOrder);			
					authorOrder++;
					pRS->MoveNext();
				}
				pRS->MoveFirst();							
				hRetval=pRS->UpdateBatch(adAffectAll);
				pRS->Filter=_variant_t((short)adFilterConflictingRecords);
				if (pRS->RecordCount > 0) 
				{
					strMsg="Could not update the following records: ";
					while (pRS->adoEOF != VARIANT_TRUE)
					{
						strMsg+=_bstr_t("(") + _bstr_t(
							pRS->Fields->Item["au_id"]->Value) 
							+ "," + _bstr_t(
							pRS->Fields->Item["title_id"]->Value)+") ";
						pRS->MoveNext();
					}
					strDescription=strMsg;
					hRetval=E_CONFLICTS_FOUND;
				}
			}
			catch ( _com_error err)
			{
				strDescription=err.Description();
				hRetval=err.Error();
			}
		}		
	}
	else 
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IAuthor,hRetval);
}

STDMETHODIMP CAuthor::GetAuthors(_Recordset **rs)
{
	HRESULT hRetval;
	_bstr_t strDescription;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	_bstr_t sql("SELECT au_id, au_fname, au_lname FROM AUTHORS");
	_RecordsetPtr pRS;
	_ConnectionPtr pConn;
	IContextState *pContxState;

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString,"","",-1);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pRS->Open(sql,pConn.GetInterfacePtr(),adOpenStatic,
				adLockBatchOptimistic,-1);
			pRS->AddRef();
			*rs=pRS;		
			pRS->PutRefActiveConnection(NULL);			
		}	
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IAuthor,hRetval);
}

STDMETHODIMP CAuthor::GetAuthorsForTitle(BSTR titleID, _Recordset **rs)
{
	HRESULT hRetval;
	_bstr_t strDescription;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	_bstr_t sql("SELECT authors.au_id, authors.au_lname,"\
		" authors.au_fname, authors.phone, authors.address,"\
		" authors.city, authors.state, titleauthor.au_ord,"\
		" titleauthor.royaltyper" \
		" FROM titleauthor "\
		" INNER JOIN authors ON titleauthor.au_id = authors.au_id"\
		" WHERE (titleauthor.title_id = ?) ORDER BY au_ord ASC");
	_RecordsetPtr pRS;
	_ConnectionPtr pConn;
	_CommandPtr pCmd;
	_ParameterPtr pParam;
	IContextState *pContxState;

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString,"","",-1);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pCmd.CreateInstance( __uuidof(Command));
			pCmd->CommandType=adCmdText;
			pCmd->CommandText=sql;
			pCmd->ActiveConnection=pConn;
			pParam=pCmd->CreateParameter(_bstr_t(L""),adVarChar,adParamInput,6,titleID);
			pCmd->Parameters->Append(pParam);
			pRS->Open(pCmd.GetInterfacePtr(),blank,adOpenStatic,
							adLockBatchOptimistic,-1);
			pRS->AddRef();
			*rs=pRS;		
			pRS->PutRefActiveConnection(NULL);			
		}	
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IAuthor,hRetval);
}

STDMETHODIMP CAuthor::GetNewTitleAuthorRecordSet(short numRecords, _Recordset **rs)
{
	_bstr_t strDescription;
	HRESULT hRetval;
	int i;
	_ConnectionPtr pConn;
	_RecordsetPtr pRS;
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	IContextState *pContxState;

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		_bstr_t sql("SELECT titleauthor.au_id, titleauthor.title_id,"\
			" titleauthor.au_ord, titleauthor.royaltyper"\
			" FROM titleauthor WHERE 1=2");		
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString,"","",-1);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pRS->Open(sql,pConn.GetInterfacePtr(),adOpenStatic,
				adLockBatchOptimistic,-1);
			pRS->AddRef();
			for (i=0;i<numRecords;i++)
				pRS->AddNew();
			pRS->MoveFirst();
			*rs=pRS;		
			pRS->PutRefActiveConnection(NULL);				
		}
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else 
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IAuthor,hRetval);
}

_bstr_t CAuthor::GetInClause(_Recordset *rs, const char *fieldName)
{
	_RecordsetPtr pRS;
	_bstr_t strTitleID;
	_bstr_t strTitleInClause;
	if (NULL != rs)
	{
		pRS=rs;
		if (pRS->RecordCount > 0 )
		{
			pRS->MoveFirst();
			pRS=rs;
			strTitleInClause="(";
			strTitleID=_bstr_t("'")+
				_bstr_t(pRS->Fields->Item[fieldName]->Value)+"'";	
			strTitleInClause+=strTitleID;
			pRS->MoveNext();
			while (pRS->adoEOF != VARIANT_TRUE)
			{				
				strTitleID=_bstr_t("'")+
					_bstr_t(pRS->Fields->Item[fieldName]->Value)+"'";
				strTitleInClause+=_bstr_t(", ") + strTitleID;
				pRS->MoveNext();
			}
			strTitleInClause+=")";
			pRS->MoveFirst();
		}
	}
	return strTitleInClause;
}
