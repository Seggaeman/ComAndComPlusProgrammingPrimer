// Publisher.cpp : Implementation of CPublisher
#include "stdafx.h"
#include "Pubsboserver.h"
#include "Publisher.h"

/////////////////////////////////////////////////////////////////////////////
// CPublisher

STDMETHODIMP CPublisher::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPublisher
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CPublisher::GetPublishers(_Recordset **rs)
{
		HRESULT hRetval;
	_bstr_t strDescription;
	_bstr_t sql("SELECT * FROM PUBLISHERS");
	_RecordsetPtr pRS;
	_ConnectionPtr pConn;	
	IContextState *pContxState;
	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContxState);
	if (SUCCEEDED(hRetval))
	{
		try 
		{
			pConn.CreateInstance( __uuidof(Connection));
			pConn->Open(mConnectionString, "", "",-1);
			pRS.CreateInstance( __uuidof(Recordset));
			pRS->CursorLocation=adUseClient;
			pRS->Open(sql,pConn.GetInterfacePtr(),adOpenStatic,
				adLockBatchOptimistic,-1);
			pRS->AddRef();
			*rs=pRS;		
			pRS->PutRefActiveConnection(NULL);		
		}
		catch ( _com_error err)
		{
			strDescription=err.Description();
			hRetval=err.Error();
		}
	}
	else
	{
		_com_error err(hRetval);
		strDescription=L"Could not retrieve the object context. " \
					   L"Your component is probably not configured";
	}
// Exit and cleanup code
	if (NULL != pContxState)
	{
		if (SUCCEEDED(hRetval))
			pContxState->SetMyTransactionVote(TxCommit);
		else
			pContxState->SetMyTransactionVote(TxAbort);
		
		pContxState->SetDeactivateOnReturn(VARIANT_TRUE);
		pContxState->Release();
	}
	if (NULL != pConn)
	{
		if (adStateOpen==pConn->GetState())
			pConn->Close();
		pConn=NULL;
	}	
	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_IPublisher,hRetval);
}
