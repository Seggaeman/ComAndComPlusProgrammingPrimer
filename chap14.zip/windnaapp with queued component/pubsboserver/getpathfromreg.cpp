#include "stdafx.h"
_bstr_t GetPathFromReg(LPCTSTR lpszKeyName)
{
	CRegKey registry;
	LPTSTR lpszKeyValue;
	DWORD dwKeyCount;
	DWORD dwDisposition;
	LONG lRegReturn;
	_bstr_t bResult;
	dwKeyCount=64;
	lpszKeyValue=new TCHAR[dwKeyCount];
	lRegReturn=registry.Create(HKEY_LOCAL_MACHINE,
		_T("Software\\agordonbooks\\pubsboserver"),
		REG_NONE,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&dwDisposition);	
	lRegReturn=registry.QueryValue(lpszKeyValue,lpszKeyName,&dwKeyCount);
	if (ERROR_SUCCESS != lRegReturn)	// indicates that there is no value
	{
		registry.SetValue(_T("C:"),lpszKeyName);
		_tcscpy(lpszKeyValue,_T("C:"));
	}
	bResult=lpszKeyValue;
	delete [] lpszKeyValue;
	return bResult;
}

