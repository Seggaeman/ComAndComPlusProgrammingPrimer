// BookPrinter.h : Declaration of the CBookPrinter

#ifndef __BOOKPRINTER_H_
#define __BOOKPRINTER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CBookPrinter
using namespace MSXML;
class ATL_NO_VTABLE CBookPrinter : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CBookPrinter, &CLSID_BookPrinter>,
	public ISupportErrorInfo,
	public IDispatchImpl<IBookPrinter, &IID_IBookPrinter, &LIBID_PUBSBOSERVERLib>
{
public:
	CBookPrinter()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_BOOKPRINTER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CBookPrinter)
	COM_INTERFACE_ENTRY(IBookPrinter)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IBookPrinter
public:
	STDMETHOD(PrintCopies)(/*[in]*/ BSTR titleID,/*[in]*/ BSTR title,/*[in]*/ short numCopies,/*[in]*/ DATE needBy,/*[in]*/ BSTR specialInstructions,/*[in]*/ DATE sentWhen);
private:
	void AddPrintJobElement(IXMLDOMDocumentPtr pDoc,IXMLDOMElementPtr pCopyJobRootElement, BSTR elementName, BSTR elementValue);
	void AddPrintJob(IXMLDOMDocumentPtr pDoc,IXMLDOMElementPtr pRootElement,BSTR titleID, BSTR title, long numCopies,DATE needBy, BSTR specialInstructions, DATE sentDate);
};

#endif //__BOOKPRINTER_H_
