 Option Explicit
 Private mTitleString As String
 Private mTitleID As String
 Public Property Let TitleString(ByVal strTitleString As String)
     mTitleString = strTitleString
 End Property
 Public Property Let TitleID(ByVal strTitleID As String)
     mTitleID = strTitleID
 End Property
 
 Private Sub chkQueueing_Click()
     On Error GoTo errHandler    
     txtPriority.Enabled = chkQueueing.Value
     updPriority.Enabled = chkQueueing.Value    
     Exit Sub
 errHandler:
     MsgBox (Err.Description)
 End Sub
 
 Private Sub cmdCancel_Click()
     On Error GoTo errHandler
     Call Unload(Me)
     Exit Sub
 errHandler:
     MsgBox (Err.Description)
 End Sub
 
 Private Sub cmdPrint_Click()
     On Error GoTo errHandler
     Dim objBookPrinter As BookPrinter
     Screen.MousePointer = vbHourglass
     If chkQueueing Then
         Set objBookPrinter = GetObject("queue:Priority=" & CInt(txtPriority.Text) & _
                 ",ComputerName=" & txtServerName.Text & "/new:pubsboserver.BookPrinter")
     Else
         Set objBookPrinter = CreateObject("pubsboserver.BookPrinter", txtServerName.Text)
     End If
     Call objBookPrinter.PrintCopies(mTitleID, mTitleString, CLng(txtNumCopies.Text), _
                 dtpNeedBy.Value, txtSpecialInstructions.Text, Now)
 ex:
     Screen.MousePointer = vbDefault
     Exit Sub
 errHandler:
     MsgBox (CStr(Err.Number) & "  " & Err.Description)
     Resume ex
 End Sub
 
 Private Sub Form_Load()
     On Error GoTo errHandler
     dtpNeedBy.Value = DateAdd("ww", 1, Date)
     Me.Caption = "Print TitleID=" & mTitleID
     Exit Sub
 errHandler:
     MsgBox (Err.Description)
 End Sub
