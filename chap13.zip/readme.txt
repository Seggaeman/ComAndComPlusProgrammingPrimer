Readme for Code.

The code for this article consists of 2 modules:

1.) A Visual C++ project that builds a COM object that is designed to run as a 
configured component under COM+.

2.) A set of HTML/ASP files.

The Visual C++ project was built on Windows 2000 beta 2 with the January, 2000 Platform
SDK. I need to change this project so that it uses the release version of 
Windows 2000. You do not have to build the project I have also included a Windows install
file, serverexportfile.msi that you can use to create a COM+ Application with the right
configuration settings. I'm not sure if the file will run on the release version of 
Windows 2000, I'm still running the beta at my home office. 

To setup the Visual C++ files you can run the installation script: 
serverexportfile.msi. This will install and register a business object server 
DLL on your machine. It will also configure the components in the DLL to run 
under COM+ with transaction support. You will need to have SQL Server 7.0 or 
greater to use this business object server as it depends on the "pubs" example 
database that ships with SQL Server 7.0. If the setup script does not work you 
can simply take the articleproject.dll file and configure it to run under COM+. 
Use "Required" for the transaction attribute.

Regardless of how you install the business object server, the Book component that 
is implemented in this server expects to get its connection string from an Object 
Construction string (this is a new feature of COM+). You can set a construction 
string on the Activation tab of the Component Properties dialog of the Windows 
2000 Component Services Explorer. You will need to set the "Enable object
Construction" checkbox and then enter a SQL Server 7.0 OLEDB connection string. An
example is shown below:

	Provider=SQLOLEDB;User ID=sa;Initial Catalog=pubs;Data Source=GORDON1

You will need to substitute the name of your machine for the Data Source. So
if your machine has the network name "MyMachine", your connection string would
be as follows:
	
	Provider=SQLOLEDB;User ID=sa;Initial Catalog=pubs;Data Source=MyMachine

To use the ASP files simply create a virtual directory under IIS and point the 
virtual directory to the location where you extracted these HTML files. In Windows
2000 use the Computer Management Explorer which you can find at on the start menu at
Start\Programs\Administrative Tools\Computer Management.
Make sure the virtual directory has been configured to run scripts. If the name of the 
virtual directory is articlepubs you should be then able to enter the following 
URL in IE or Netscape: http://[servername]/articlepubs and that should bring up 
an HTML page that contains an edit box. Type in a keyword or just a letter, for
example, the letter "e". You should see a list of books whose titles contain the 
keyword. The titleID in the list is a hyperlink, if you click on the hyperlink
you should see a page that allows you to edit the information for that book. Alter
some of the fields then click the submit button. The book should be updated.


to type in a keyword to search on. I will provide more detailed setup instructions before
this article goes to print.
