// Book.h : Declaration of the CBook

#ifndef __BOOK_H_
#define __BOOK_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CBook
class ATL_NO_VTABLE CBook : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CBook, &CLSID_Book>,
	public ISupportErrorInfo,
	public IDispatchImpl<IBook, &IID_IBook, &LIBID_PUBSBOSERVERLib>,
	public IObjectConstruct
{
public:
	CBook()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_BOOK)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CBook)
	COM_INTERFACE_ENTRY(IBook)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IObjectConstruct)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IBook
public:
	STDMETHOD(UpdateBooks)(/*[in]*/ _Recordset *rsBookInfo,/*[in]*/ _Recordset *rsAuthorInfo);
	STDMETHOD(DeleteBook)(/*[in]*/ BSTR id);
	STDMETHOD(GetExistingBookRecordSet)(/*[in]*/ BSTR criterion,/*[out,retval]*/ _Recordset ** rs);
	STDMETHOD(GetNewBookRecordSet)(/*[in]*/ short numRecords,/*[out,retval]*/ _Recordset **rs);
	STDMETHOD(RetrieveByID)(/*[in]*/ BSTR id, /*[out,retval]*/ _Recordset** rs);
	STDMETHOD(RetrieveByKeyword)(/*[in]*/ BSTR keyword,/*[out,retval]*/ _Recordset ** rs);
	STDMETHOD(Construct) (IDispatch *pCtorObj)
	{
		_bstr_t strDescription;
		HRESULT hRetval;
		IObjectConstructString *pStr;
		BSTR strConstruct;
		if (pCtorObj != NULL)
		{

			hRetval=pCtorObj->QueryInterface(IID_IObjectConstructString,(void **)&pStr);
			if (SUCCEEDED(hRetval))
			{
				hRetval=pStr->get_ConstructString(&strConstruct);
				if (SUCCEEDED(hRetval))
				{
					mConnectionString=strConstruct;
					SysFreeString(strConstruct);
				}				
				pStr->Release();
			}
			else
			{
				_com_error err(hRetval);
				strDescription=err.Description();
				ATLTRACE(err.ErrorMessage());
			}
		}
		else
		{			
			hRetval=E_POINTER;
			strDescription=L"An invalid pointer was passed to Construct";
		}
		if (S_OK==hRetval)
			return hRetval;
		else
			return Error((LPOLESTR)strDescription,IID_IBook,hRetval);
	}
private:
	_bstr_t mConnectionString;
};

#endif //__BOOK_H_
