
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Sun Apr 30 22:45:33 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter13\windnaapp\pubsboserver\pubsboserver.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AXP64)

#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, LIBID_PUBSBOSERVERLib,0xE8A2C16F,0xF48E,0x4DE4,0x8E,0x49,0x56,0x13,0xA7,0x88,0xBB,0xE7);


MIDL_DEFINE_GUID(IID, IID_IBook,0x4A2834F0,0xB825,0x438B,0xA8,0xE2,0x0F,0x5E,0x49,0x73,0x2E,0x5D);


MIDL_DEFINE_GUID(IID, IID_IAuthor,0x360A71F7,0x37A3,0x46DD,0x91,0x71,0x23,0x6A,0x4B,0xC8,0x87,0xFA);


MIDL_DEFINE_GUID(IID, IID_IPublisher,0x5E3070A9,0x0C5B,0x48DD,0xBD,0xF6,0xD4,0x41,0xC4,0x99,0x61,0x16);


MIDL_DEFINE_GUID(CLSID, CLSID_Book,0x4C4F35F1,0x4206,0x464B,0xBE,0x53,0x1C,0x42,0x6C,0x82,0x1D,0xA9);


MIDL_DEFINE_GUID(CLSID, CLSID_Author,0xCF5C98BE,0xAE8B,0x4120,0xA7,0xE4,0x84,0xAB,0x8C,0x37,0xE4,0x6B);


MIDL_DEFINE_GUID(CLSID, CLSID_Publisher,0xA746E063,0x4E76,0x4F6F,0xAD,0x1E,0x42,0xBA,0x1F,0x99,0xFF,0x2C);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



#endif /* !defined(_M_IA64) && !defined(_M_AXP64)*/


#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Sun Apr 30 22:45:33 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter13\windnaapp\pubsboserver\pubsboserver.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win64 (32b run,appending), ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if defined(_M_IA64) || defined(_M_AXP64)

#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, LIBID_PUBSBOSERVERLib,0xE8A2C16F,0xF48E,0x4DE4,0x8E,0x49,0x56,0x13,0xA7,0x88,0xBB,0xE7);


MIDL_DEFINE_GUID(IID, IID_IBook,0x4A2834F0,0xB825,0x438B,0xA8,0xE2,0x0F,0x5E,0x49,0x73,0x2E,0x5D);


MIDL_DEFINE_GUID(IID, IID_IAuthor,0x360A71F7,0x37A3,0x46DD,0x91,0x71,0x23,0x6A,0x4B,0xC8,0x87,0xFA);


MIDL_DEFINE_GUID(IID, IID_IPublisher,0x5E3070A9,0x0C5B,0x48DD,0xBD,0xF6,0xD4,0x41,0xC4,0x99,0x61,0x16);


MIDL_DEFINE_GUID(CLSID, CLSID_Book,0x4C4F35F1,0x4206,0x464B,0xBE,0x53,0x1C,0x42,0x6C,0x82,0x1D,0xA9);


MIDL_DEFINE_GUID(CLSID, CLSID_Author,0xCF5C98BE,0xAE8B,0x4120,0xA7,0xE4,0x84,0xAB,0x8C,0x37,0xE4,0x6B);


MIDL_DEFINE_GUID(CLSID, CLSID_Publisher,0xA746E063,0x4E76,0x4F6F,0xAD,0x1E,0x42,0xBA,0x1F,0x99,0xFF,0x2C);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



#endif /* defined(_M_IA64) || defined(_M_AXP64)*/

