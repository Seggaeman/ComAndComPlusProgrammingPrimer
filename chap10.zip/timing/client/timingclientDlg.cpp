// timingclientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "timingclient.h"
#include "timingclientDlg.h"
#include "..\outofprocess server\svroutofprocess.h"
#include "..\outofprocess server\svroutofprocess_i.c"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// Disable warnings about conversion of __int64 to float and long
#pragma warning( disable : 4244 ) 
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimingclientDlg dialog

CTimingclientDlg::CTimingclientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTimingclientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTimingclientDlg)
	m_timesToCall = 0;
	m_totalTime = 0;
	m_timePerCall = 0.0f;
	m_remoteServerName = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTimingclientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTimingclientDlg)
	DDX_Control(pDX, IDC_TESTARGS_BUTTON, m_testOutOfProcessWithArgsButton);
	DDX_Control(pDX, IDC_TEST_BUTTON, m_testOutOfProcessButton);
	DDX_Text(pDX, IDC_TIMESTOCALL_EDIT, m_timesToCall);
	DDX_Text(pDX, IDC_TOTALTIME_EDIT, m_totalTime);
	DDX_Text(pDX, IDC_TIMEPERCALL_EDIT, m_timePerCall);
	DDX_Text(pDX, IDC_REMOTE_SERVER_NAME_EDIT, m_remoteServerName);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTimingclientDlg, CDialog)
	//{{AFX_MSG_MAP(CTimingclientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_TEST_BUTTON, OnTestButton)
	ON_BN_CLICKED(IDC_TESTINPROCESS_BUTTON, OnTestinprocessButton)
	ON_BN_CLICKED(IDC_TESTARGS_BUTTON, OnTestargsButton)
	ON_BN_CLICKED(IDC_INPROCESSTESTARGS_BUTTON, OnInprocesstestargsButton)
	ON_BN_CLICKED(IDC_REMOTE_SERVER_BUTTON, OnRemoteServerButton)
	ON_BN_CLICKED(IDC_DEFAULT_SERVER_BUTTON, OnUseDefaultButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimingclientDlg message handlers

BOOL CTimingclientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	if (FALSE==QueryPerformanceFrequency((LARGE_INTEGER*)&m_highResFrequency))
	{
		AfxMessageBox("Could not get high resolution timer");
		return FALSE;
	}
	
	HRESULT hRes;
/*
	hRes=mServerOutOfProcess.CreateInstance("svroutofprocess.testclass");
	if (FAILED(hRes))
	{
		_com_error err(hRes);
		AfxMessageBox(err.ErrorMessage());

	}
*/
	hRes=mServerInProcess.CreateInstance("svrinprocess.testclass");
	if (FAILED(hRes))
	{
		_com_error err(hRes);
		AfxMessageBox(err.ErrorMessage());

	}
	DisableButtons();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTimingclientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTimingclientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTimingclientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTimingclientDlg::OnTestButton() 
{
	long i;
	__int64 startTime, stopTime;
	UpdateData(TRUE);

	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}
 
	for (i=0;i<m_timesToCall;i++) {
		mServerOutOfProcess->LongOperation();
	}
	
	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}
	m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
	if (m_timesToCall > 0)
		m_timePerCall=m_totalTime/m_timesToCall;
	else
		m_timePerCall=0;
	UpdateData(FALSE);
}



void CTimingclientDlg::OnTestargsButton() 
{
	long i, returnValue;
	__int64 startTime, stopTime;

	double arg2;
	unsigned char arg3[2048];
	UpdateData(TRUE);

	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}

	for (i=0;i<m_timesToCall;i++) {
		returnValue=mServerOutOfProcess->LongOperationArgs(OLESTR("ALAN"),&arg2,arg3);
	}

	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}

	m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
	if (m_timesToCall > 0)
		m_timePerCall=m_totalTime/m_timesToCall;
	else
		m_timePerCall=0;
	UpdateData(FALSE);
}

void CTimingclientDlg::OnTestinprocessButton() 
{
	long i;
	__int64 startTime, stopTime;
	UpdateData(TRUE);

	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}

	for (i=0;i<m_timesToCall;i++) {
		mServerInProcess->LongOperation();
	}

	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}

	m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
	if (m_timesToCall > 0)
		m_timePerCall=m_totalTime/m_timesToCall;
	else
		m_timePerCall=0;
	UpdateData(FALSE);
}

void CTimingclientDlg::OnInprocesstestargsButton() 
{
	long i, returnValue;
	__int64 startTime, stopTime;
	double arg2;
	unsigned char arg3[2048];
	UpdateData(TRUE);

	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}

	for (i=0;i<m_timesToCall;i++) {
		returnValue=mServerInProcess->LongOperationArgs(OLESTR("ALAN"),&arg2,arg3);
	}

	if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) {
		AfxMessageBox("Count not get start counter");
		return;
	}

	m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
	if (m_timesToCall > 0)
		m_timePerCall=m_totalTime/m_timesToCall;
	else
		m_timePerCall=0;
	UpdateData(FALSE);
}

void CTimingclientDlg::OnRemoteServerButton() 
{
	UpdateData(TRUE);
	CLSID clsid;
	HRESULT hRes;
	BSTR serverName=m_remoteServerName.AllocSysString();
	MULTI_QI multiQI={ &IID_ITestClass,NULL,NOERROR };
	COSERVERINFO serverInfo={ 0,serverName,NULL,0 };	

	DisableButtons();	
	hRes=::CLSIDFromProgID(L"svroutofprocess.testclass",&clsid);
	if (FAILED(hRes))
	{
		AfxMessageBox("Server not registered on remote machine");
		return;
	}
	hRes=CoCreateInstanceEx(clsid,NULL,CLSCTX_ALL,&serverInfo,1,&multiQI);
	if (FAILED(hRes))
	{
		_com_error err(hRes);
		AfxMessageBox(err.ErrorMessage());
	}
	else
	{
		mServerOutOfProcess=(ITestClass*)multiQI.pItf;
		EnableButtons();
	}	
	::SysFreeString(serverName);
}

void CTimingclientDlg::OnUseDefaultButton() 
{
	HRESULT hRes;
	DisableButtons();
	hRes=mServerOutOfProcess.CreateInstance("svroutofprocess.testclass");
	if (FAILED(hRes))
	{
		_com_error err(hRes);
		AfxMessageBox(err.ErrorMessage());

	}
	else
		EnableButtons();
}

void CTimingclientDlg::EnableButtons()
{
	m_testOutOfProcessButton.EnableWindow(TRUE);
	m_testOutOfProcessWithArgsButton.EnableWindow(TRUE);
}

void CTimingclientDlg::DisableButtons()
{
	m_testOutOfProcessButton.EnableWindow(FALSE);
	m_testOutOfProcessWithArgsButton.EnableWindow(FALSE);
}
