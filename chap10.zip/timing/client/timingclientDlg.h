// timingclientDlg.h : header file
//

#if !defined(AFX_TIMINGCLIENTDLG_H__0BD94507_130C_11D3_998A_74EE08C10000__INCLUDED_)
#define AFX_TIMINGCLIENTDLG_H__0BD94507_130C_11D3_998A_74EE08C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTimingclientDlg dialog
class CTimingclientDlg : public CDialog
{
// Construction
public:
	CTimingclientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTimingclientDlg)
	enum { IDD = IDD_TIMINGCLIENT_DIALOG };
	CButton	m_testOutOfProcessWithArgsButton;
	CButton	m_testOutOfProcessButton;
	long	m_timesToCall;
	long	m_totalTime;
	float	m_timePerCall;
	CString	m_remoteServerName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTimingclientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTimingclientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTestButton();
	afx_msg void OnTestinprocessButton();
	afx_msg void OnTestargsButton();
	afx_msg void OnInprocesstestargsButton();
	afx_msg void OnRemoteServerButton();
	afx_msg void OnUseDefaultButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DisableButtons();
	void EnableButtons();
	__int64 m_highResFrequency;
	SVROUTOFPROCESSLib::ITestClassPtr mServerOutOfProcess;
	SVRINPROCESSLib::ITestClassPtr mServerInProcess;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIMINGCLIENTDLG_H__0BD94507_130C_11D3_998A_74EE08C10000__INCLUDED_)
