// TestClass.h : Declaration of the CTestClass

#ifndef __TESTClASS_H_
#define __TESTCLASS_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestClass
class ATL_NO_VTABLE CTestClass : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CTestClass, &CLSID_TestClass>,
	public ISupportErrorInfo,
	public ITestClass
{
public:
	CTestClass()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_TESTCLASS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTestClass)
	COM_INTERFACE_ENTRY(ITestClass)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ITestClass
public:
	STDMETHOD(LongOperationArgs)(/*[in,string]*/ LPOLESTR arg1,/*[out]*/ double *arg2,/*[out,size_is(255)]*/ unsigned char *arg3,/*[out,retval]*/ long *milliSecs);
	STDMETHOD(LongOperation)();
};

#endif //__TESTCLASS_H_
