// timingclientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "timingclient.h"
#include "timingclientDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// Disable warnings about conversion of __int64 to float and long
#pragma warning( disable : 4244 )  
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimingclientDlg dialog

CTimingclientDlg::CTimingclientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTimingclientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTimingclientDlg)
	m_timesToCall = 10;
	m_totalTime = 0;
	m_timePerCall = 0.0f;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTimingclientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTimingclientDlg)
	DDX_Text(pDX, IDC_TIMESTOCALL_EDIT, m_timesToCall);
	DDX_Text(pDX, IDC_TOTALTIME_EDIT, m_totalTime);
	DDX_Text(pDX, IDC_TIMEPERCALL_EDIT, m_timePerCall);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTimingclientDlg, CDialog)
	//{{AFX_MSG_MAP(CTimingclientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_TEST_BUTTON, OnTestButton)
	ON_BN_CLICKED(IDC_TESTINPROCESS_BUTTON, OnTestinprocessButton)
	ON_BN_CLICKED(IDC_TESTARGS_BUTTON, OnTestargsButton)
	ON_BN_CLICKED(IDC_INPROCESSTESTARGS_BUTTON, OnInprocesstestargsButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTimingclientDlg message handlers

BOOL CTimingclientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	if (FALSE==QueryPerformanceFrequency((LARGE_INTEGER*)&m_highResFrequency))
	{
		AfxMessageBox("Could not get high resolution timer");
		return FALSE;
	}
	
	HRESULT hRes;
	hRes=mServerOutOfProcess.CreateInstance("svroutofprocess.testclass");
	if (FAILED(hRes))
	{
		if (E_NOINTERFACE==hRes)
		{
			AfxMessageBox("Could not get the desired interface.\n" \
					"Make sure you have registered the marshaling DLL. \n" \
					"See chapter 6 for more details.");
		}
		else
			AfxMessageBox("Could not instantiate the out of process server.\n" \
					"Make sure it is registered.");
		

	}
	hRes=mServerInProcess.CreateInstance("svrinprocess.testclass");
	if (FAILED(hRes))
	{
		AfxMessageBox("Could not instantiate the in process server.\n" \
				"Make sure it is registered.");

	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTimingclientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTimingclientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTimingclientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTimingclientDlg::OnTestButton() 
{
	long i;
	__int64 startTime, stopTime;

	if (mServerOutOfProcess)
	{
		UpdateData(TRUE);
		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) {
			AfxMessageBox("Count not get start counter");
			return;
		}
 
		for (i=0;i<m_timesToCall;i++) {
			mServerOutOfProcess->LongOperation();
		}
		
		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) {
			AfxMessageBox("Count not get start counter");
			return;
		}
		m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
		if (m_timesToCall > 0)
			m_timePerCall=m_totalTime/m_timesToCall;
		else
			m_timePerCall=0;
		UpdateData(FALSE);
	}
	else
		AfxMessageBox("The out of process server failed to start.");
}



void CTimingclientDlg::OnTestargsButton() 
{
	long i, returnValue;
	__int64 startTime, stopTime;

	double arg2;
	unsigned char arg3[2048];
	
	if (mServerOutOfProcess)
	{		
		UpdateData(TRUE);
		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) 
		{
			AfxMessageBox("Count not get start counter");
			return;
		}

		for (i=0;i<m_timesToCall;i++) 
		{
			returnValue=mServerOutOfProcess->LongOperationArgs(OLESTR("ALAN"),&arg2,arg3);
		}

		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) 
		{
			AfxMessageBox("Count not get start counter");
			return;
		}

		m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
		if (m_timesToCall > 0)
			m_timePerCall=m_totalTime/m_timesToCall;
		else
			m_timePerCall=0;
		UpdateData(FALSE);
	}
	else
		AfxMessageBox("The out of process server failed to start.");
}

void CTimingclientDlg::OnTestinprocessButton() 
{
	long i;
	__int64 startTime, stopTime;

	if (mServerInProcess)
	{
		UpdateData(TRUE);
		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) {
			AfxMessageBox("Count not get start counter");
			return;
		}

		for (i=0;i<m_timesToCall;i++) {
			mServerInProcess->LongOperation();
		}

		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) {
			AfxMessageBox("Count not get start counter");
			return;
		}

		m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
		if (m_timesToCall > 0)
			m_timePerCall=m_totalTime/m_timesToCall;
		else
			m_timePerCall=0;
		UpdateData(FALSE);
	}
	else
		AfxMessageBox("The in process server failed to start.");
}

void CTimingclientDlg::OnInprocesstestargsButton() 
{
	long i, returnValue;
	__int64 startTime, stopTime;
	double arg2;
	unsigned char arg3[2048];

	if (mServerInProcess)
	{
		UpdateData(TRUE);

		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&startTime)) 
		{
			AfxMessageBox("Count not get start counter");
			return;
		}

		for (i=0;i<m_timesToCall;i++) 
			returnValue=mServerInProcess->LongOperationArgs(OLESTR("ALAN"),&arg2,arg3);

		if (FALSE==QueryPerformanceCounter((LARGE_INTEGER*)&stopTime)) {
			AfxMessageBox("Count not get start counter");
			return;
		}

		m_totalTime=((stopTime-startTime)*1000000)/m_highResFrequency;
		if (m_timesToCall > 0)
			m_timePerCall=m_totalTime/m_timesToCall;
		else
			m_timePerCall=0;
		UpdateData(FALSE);
	}
	else
		AfxMessageBox("The in process server failed to start.");
}
