// TestClass.cpp : Implementation of CTestClass
#include "stdafx.h"
#include "Svroutofprocess.h"
#include "TestObject.h"

/////////////////////////////////////////////////////////////////////////////
// CTestClass

STDMETHODIMP CTestClass::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ITestClass
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CTestClass::LongOperation()
{	
	
	return S_OK;
}

STDMETHODIMP CTestClass::LongOperationArgs(LPOLESTR arg1, double *arg2, unsigned char *arg3, long *returnValue)
{
	
	return S_OK;
}
