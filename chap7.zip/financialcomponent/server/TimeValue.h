// TimeValue.h : Declaration of the CTimeValue

#ifndef __TIMEVALUE_H_
#define __TIMEVALUE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTimeValue
class ATL_NO_VTABLE CTimeValue : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CTimeValue, &CLSID_TimeValue>,
	public ISupportErrorInfo,
	public IDispatchImpl<ITimeValue, &IID_ITimeValue, &LIBID_FINANCIALCOMPONENTLib>,
	public IDispatchImpl<ITaxCalculator, &IID_ITaxCalculator, &LIBID_FINANCIALCOMPONENTLib>
{
public:
	CTimeValue()
	{
		mInterestRate=8.0;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_TIMEVALUE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTimeValue)
	COM_INTERFACE_ENTRY(ITimeValue)
//DEL 	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY2(IDispatch, ITimeValue)
	COM_INTERFACE_ENTRY(ITaxCalculator)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ITimeValue
public:
	STDMETHOD(CalculateTax)(/*[in]*/ double earnings,/*[out,retval]*/ double *tax);
	STDMETHOD(LoanAmount)(/*[in]*/ short numMonths,/*[in]*/ double monthlyPayment,/*[out,retval]*/ double * loanAmount);
	STDMETHOD(MonthlyPayment)(/*[in]*/ short numMonths,/*[in]*/ double loanAmount, /*[out,retval]*/ double *result);
	STDMETHOD(get_InterestRate)(/*[out, retval]*/ double *pVal);
	STDMETHOD(put_InterestRate)(/*[in]*/ double newVal);
// ITaxCalculator
private:
	double mInterestRate;
};

#endif //__TIMEVALUE_H_
