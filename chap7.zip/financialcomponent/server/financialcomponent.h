/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Mar 29 12:06:21 2000
 */
/* Compiler settings for E:\Alan\vcppbook\readydemos\chapter7\financialcomponent\server\financialcomponent.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __financialcomponent_h__
#define __financialcomponent_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ITimeValue_FWD_DEFINED__
#define __ITimeValue_FWD_DEFINED__
typedef interface ITimeValue ITimeValue;
#endif 	/* __ITimeValue_FWD_DEFINED__ */


#ifndef __ITaxCalculator_FWD_DEFINED__
#define __ITaxCalculator_FWD_DEFINED__
typedef interface ITaxCalculator ITaxCalculator;
#endif 	/* __ITaxCalculator_FWD_DEFINED__ */


#ifndef __TimeValue_FWD_DEFINED__
#define __TimeValue_FWD_DEFINED__

#ifdef __cplusplus
typedef class TimeValue TimeValue;
#else
typedef struct TimeValue TimeValue;
#endif /* __cplusplus */

#endif 	/* __TimeValue_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ITimeValue_INTERFACE_DEFINED__
#define __ITimeValue_INTERFACE_DEFINED__

/* interface ITimeValue */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITimeValue;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("EB47FA0D-22EE-11D3-998A-E0EC08C10000")
    ITimeValue : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_InterestRate( 
            /* [retval][out] */ double __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_InterestRate( 
            /* [in] */ double newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MonthlyPayment( 
            /* [in] */ short numMonths,
            /* [in] */ double loanAmount,
            /* [retval][out] */ double __RPC_FAR *result) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LoanAmount( 
            /* [in] */ short numMonths,
            /* [in] */ double monthlyPayment,
            /* [retval][out] */ double __RPC_FAR *loanAmount) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITimeValueVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITimeValue __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITimeValue __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITimeValue __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITimeValue __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITimeValue __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITimeValue __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITimeValue __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_InterestRate )( 
            ITimeValue __RPC_FAR * This,
            /* [retval][out] */ double __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_InterestRate )( 
            ITimeValue __RPC_FAR * This,
            /* [in] */ double newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MonthlyPayment )( 
            ITimeValue __RPC_FAR * This,
            /* [in] */ short numMonths,
            /* [in] */ double loanAmount,
            /* [retval][out] */ double __RPC_FAR *result);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoanAmount )( 
            ITimeValue __RPC_FAR * This,
            /* [in] */ short numMonths,
            /* [in] */ double monthlyPayment,
            /* [retval][out] */ double __RPC_FAR *loanAmount);
        
        END_INTERFACE
    } ITimeValueVtbl;

    interface ITimeValue
    {
        CONST_VTBL struct ITimeValueVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITimeValue_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITimeValue_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITimeValue_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITimeValue_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITimeValue_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITimeValue_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITimeValue_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITimeValue_get_InterestRate(This,pVal)	\
    (This)->lpVtbl -> get_InterestRate(This,pVal)

#define ITimeValue_put_InterestRate(This,newVal)	\
    (This)->lpVtbl -> put_InterestRate(This,newVal)

#define ITimeValue_MonthlyPayment(This,numMonths,loanAmount,result)	\
    (This)->lpVtbl -> MonthlyPayment(This,numMonths,loanAmount,result)

#define ITimeValue_LoanAmount(This,numMonths,monthlyPayment,loanAmount)	\
    (This)->lpVtbl -> LoanAmount(This,numMonths,monthlyPayment,loanAmount)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITimeValue_get_InterestRate_Proxy( 
    ITimeValue __RPC_FAR * This,
    /* [retval][out] */ double __RPC_FAR *pVal);


void __RPC_STUB ITimeValue_get_InterestRate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITimeValue_put_InterestRate_Proxy( 
    ITimeValue __RPC_FAR * This,
    /* [in] */ double newVal);


void __RPC_STUB ITimeValue_put_InterestRate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITimeValue_MonthlyPayment_Proxy( 
    ITimeValue __RPC_FAR * This,
    /* [in] */ short numMonths,
    /* [in] */ double loanAmount,
    /* [retval][out] */ double __RPC_FAR *result);


void __RPC_STUB ITimeValue_MonthlyPayment_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITimeValue_LoanAmount_Proxy( 
    ITimeValue __RPC_FAR * This,
    /* [in] */ short numMonths,
    /* [in] */ double monthlyPayment,
    /* [retval][out] */ double __RPC_FAR *loanAmount);


void __RPC_STUB ITimeValue_LoanAmount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITimeValue_INTERFACE_DEFINED__ */


#ifndef __ITaxCalculator_INTERFACE_DEFINED__
#define __ITaxCalculator_INTERFACE_DEFINED__

/* interface ITaxCalculator */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITaxCalculator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1C208680-22F2-11d3-998A-E0EC08C10000")
    ITaxCalculator : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CalculateTax( 
            /* [in] */ double earnings,
            /* [retval][out] */ double __RPC_FAR *tax) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITaxCalculatorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITaxCalculator __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITaxCalculator __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITaxCalculator __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITaxCalculator __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITaxCalculator __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITaxCalculator __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITaxCalculator __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CalculateTax )( 
            ITaxCalculator __RPC_FAR * This,
            /* [in] */ double earnings,
            /* [retval][out] */ double __RPC_FAR *tax);
        
        END_INTERFACE
    } ITaxCalculatorVtbl;

    interface ITaxCalculator
    {
        CONST_VTBL struct ITaxCalculatorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITaxCalculator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITaxCalculator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITaxCalculator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITaxCalculator_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITaxCalculator_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITaxCalculator_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITaxCalculator_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITaxCalculator_CalculateTax(This,earnings,tax)	\
    (This)->lpVtbl -> CalculateTax(This,earnings,tax)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITaxCalculator_CalculateTax_Proxy( 
    ITaxCalculator __RPC_FAR * This,
    /* [in] */ double earnings,
    /* [retval][out] */ double __RPC_FAR *tax);


void __RPC_STUB ITaxCalculator_CalculateTax_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITaxCalculator_INTERFACE_DEFINED__ */



#ifndef __FINANCIALCOMPONENTLib_LIBRARY_DEFINED__
#define __FINANCIALCOMPONENTLib_LIBRARY_DEFINED__

/* library FINANCIALCOMPONENTLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_FINANCIALCOMPONENTLib;

EXTERN_C const CLSID CLSID_TimeValue;

#ifdef __cplusplus

class DECLSPEC_UUID("EB47FA0E-22EE-11D3-998A-E0EC08C10000")
TimeValue;
#endif
#endif /* __FINANCIALCOMPONENTLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
