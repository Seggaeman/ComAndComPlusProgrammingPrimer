// TimeValue.cpp : Implementation of CTimeValue
#include "stdafx.h"
#include "Financialcomponent.h"
#include "TimeValue.h"
#include <math.h>
/////////////////////////////////////////////////////////////////////////////
// CTimeValue
struct TaxBracket 
{
	double minIncome;
	double taxRate;	
};

STDMETHODIMP CTimeValue::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ITimeValue
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CTimeValue::get_InterestRate(double *pVal)
{
	*pVal=mInterestRate;
	return S_OK;
}

STDMETHODIMP CTimeValue::put_InterestRate(double newVal)
{
	mInterestRate=newVal;
	return S_OK;
}

STDMETHODIMP CTimeValue::MonthlyPayment(short numMonths, double loanAmount, double *monthlyPayment)
{
	double monthlyRate, tempVal;
	monthlyRate=mInterestRate/1200;  // Convert A.P.R. to decimal, monthly rate
	tempVal=pow((1+monthlyRate),(double)numMonths);
	*monthlyPayment=loanAmount*monthlyRate*tempVal/(tempVal-1);
	return S_OK;
}

STDMETHODIMP CTimeValue::LoanAmount(short numMonths, double monthlyPayment, double *loanAmount)
{
	double monthlyRate, tempVal;
	monthlyRate=mInterestRate/1200;  // Convert A.P.R. to decimal, monthly rate
	tempVal=pow((1+monthlyRate),(double)numMonths);
	*loanAmount=monthlyPayment*(tempVal-1)/(monthlyRate*tempVal);
	return S_OK;
}

STDMETHODIMP CTimeValue::CalculateTax(double earnings, double *tax)
{
	static TaxBracket taxBrackets[4]={{128700.0,.396},{61400.0,.33},
										{25350.0,.28},{0.0,.15}};
	double taxAmount, incomeInBracket;
	int i;
	TaxBracket aTaxBracket;
	taxAmount=0.0;
	for (i=0;i<4;i++)
	{
		aTaxBracket=taxBrackets[i];
		if (earnings >= aTaxBracket.minIncome)
		{
			incomeInBracket=earnings-aTaxBracket.minIncome;
			taxAmount+=incomeInBracket*aTaxBracket.taxRate;
			earnings=aTaxBracket.minIncome;
		}
	}
	*tax=taxAmount;
	return S_OK;
}
