#include <string.h>
#include <fstream>
#include <iterator>
#include "spellcheckimpl.h"
const E_DICTIONARYFILENOTFOUND=MAKE_HRESULT(
			SEVERITY_ERROR,FACILITY_ITF,0x200+25);
CSpellCheckImpl::CSpellCheckImpl()
{
	string str;
	str="Alan";
	m_dictionary.push_back(str);
	str="Gordon";
	m_dictionary.push_back(str);
	str="COM";
	m_dictionary.push_back(str);
	str="COM+";
	m_dictionary.push_back(str);
	str="Programming";
	m_dictionary.push_back(str);
}

CSpellCheckImpl::~CSpellCheckImpl()
{
}

STDMETHODIMP_(ULONG) CSpellCheckImpl::AddRef(void)
{
    return ++m_ref;
}


STDMETHODIMP_(ULONG) CSpellCheckImpl::Release(void)
{
    if (0L!=--m_ref)
        return m_ref;

    delete this;
    return 0;
}

STDMETHODIMP CSpellCheckImpl::QueryInterface(REFIID riid,
							     void** ppv)
{
	if (IID_IUnknown==riid || IID_ISpellChecker==riid)
	{
		*ppv=this;
		AddRef();
		return S_OK;
	} 	else
	{
		*ppv=NULL;
		return E_NOINTERFACE;
	}
}

STDMETHODIMP  CSpellCheckImpl::CheckSpelling(
				unsigned char *word,BOOL *isCorrect)
{
	string str;
	vector< string >::iterator iter;
	*isCorrect=FALSE;
	for (iter=m_dictionary.begin();iter!=m_dictionary.end();iter++) {
		str=*iter;
		if (stricmp(str.c_str(),(const char *)word)==0) {
			*isCorrect=TRUE;
			break;
		}
	}
	return NOERROR;
}

STDMETHODIMP  CSpellCheckImpl::UseCustomDictionary(
				unsigned char *filename)
{
	string str;
	char tempBuffer[255];
	ifstream dictionaryFile;
	dictionaryFile.open((const char *)filename);
	if (!dictionaryFile.is_open())
		return E_DICTIONARYFILENOTFOUND;
	while (!dictionaryFile.eof())  {
		dictionaryFile.getline(tempBuffer,255);
		str= tempBuffer;
		m_dictionary.push_back(str);
	}
	return NOERROR;
}
