
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Mon May 01 02:33:07 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter4\spellchecker\server\spellcheck.idl:
    Os (OptLev=s), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __spellcheck_h__
#define __spellcheck_h__

/* Forward Declarations */ 

#ifndef __ISpellChecker_FWD_DEFINED__
#define __ISpellChecker_FWD_DEFINED__
typedef interface ISpellChecker ISpellChecker;
#endif 	/* __ISpellChecker_FWD_DEFINED__ */


#ifndef __CSpellChecker_FWD_DEFINED__
#define __CSpellChecker_FWD_DEFINED__

#ifdef __cplusplus
typedef class CSpellChecker CSpellChecker;
#else
typedef struct CSpellChecker CSpellChecker;
#endif /* __cplusplus */

#endif 	/* __CSpellChecker_FWD_DEFINED__ */


/* header files for imported files */
#include "unknwn.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ISpellChecker_INTERFACE_DEFINED__
#define __ISpellChecker_INTERFACE_DEFINED__

/* interface ISpellChecker */
/* [uuid][object] */ 


EXTERN_C const IID IID_ISpellChecker;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("704A8520-E4E9-11d0-BCCE-00A024BD9ECC")
    ISpellChecker : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE CheckSpelling( 
            /* [string][in] */ unsigned char __RPC_FAR *word,
            /* [retval][out] */ BOOL __RPC_FAR *isCorrect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UseCustomDictionary( 
            /* [string][in] */ unsigned char __RPC_FAR *filename) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISpellCheckerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISpellChecker __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISpellChecker __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISpellChecker __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckSpelling )( 
            ISpellChecker __RPC_FAR * This,
            /* [string][in] */ unsigned char __RPC_FAR *word,
            /* [retval][out] */ BOOL __RPC_FAR *isCorrect);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UseCustomDictionary )( 
            ISpellChecker __RPC_FAR * This,
            /* [string][in] */ unsigned char __RPC_FAR *filename);
        
        END_INTERFACE
    } ISpellCheckerVtbl;

    interface ISpellChecker
    {
        CONST_VTBL struct ISpellCheckerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISpellChecker_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISpellChecker_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISpellChecker_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISpellChecker_CheckSpelling(This,word,isCorrect)	\
    (This)->lpVtbl -> CheckSpelling(This,word,isCorrect)

#define ISpellChecker_UseCustomDictionary(This,filename)	\
    (This)->lpVtbl -> UseCustomDictionary(This,filename)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISpellChecker_CheckSpelling_Proxy( 
    ISpellChecker __RPC_FAR * This,
    /* [string][in] */ unsigned char __RPC_FAR *word,
    /* [retval][out] */ BOOL __RPC_FAR *isCorrect);


void __RPC_STUB ISpellChecker_CheckSpelling_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISpellChecker_UseCustomDictionary_Proxy( 
    ISpellChecker __RPC_FAR * This,
    /* [string][in] */ unsigned char __RPC_FAR *filename);


void __RPC_STUB ISpellChecker_UseCustomDictionary_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISpellChecker_INTERFACE_DEFINED__ */



#ifndef __SpellcheckerLib_LIBRARY_DEFINED__
#define __SpellcheckerLib_LIBRARY_DEFINED__

/* library SpellcheckerLib */
/* [uuid] */ 


EXTERN_C const IID LIBID_SpellcheckerLib;

EXTERN_C const CLSID CLSID_CSpellChecker;

#ifdef __cplusplus

class DECLSPEC_UUID("57B7A8A0-E4D7-11d0-818D-444553540000")
CSpellChecker;
#endif
#endif /* __SpellcheckerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


