#include "spellfactoryimpl.h"
#include "spellcheckimpl.h" // spellchecker implementation
extern LONG gLockCount, gObjectCount;
CSpellFactoryImpl::CSpellFactoryImpl()
{
	m_ref=0;
}

CSpellFactoryImpl::~CSpellFactoryImpl()
{
}

STDMETHODIMP_(ULONG) CSpellFactoryImpl::AddRef(void)
{
    return ++m_ref;
}

STDMETHODIMP_(ULONG) CSpellFactoryImpl::Release(void)
{
    if (0L!=--m_ref)
        return m_ref;

    delete this;
    return 0;
}

STDMETHODIMP CSpellFactoryImpl::QueryInterface(REFIID riid,void** ppv)
{
    	if (IID_IUnknown==riid || IID_IClassFactory==riid) {
		*ppv=this;
		AddRef();
		return S_OK;
	} 	
	else {
		*ppv=NULL;
		return E_NOINTERFACE;
	}
}

STDMETHODIMP CSpellFactoryImpl::CreateInstance(LPUNKNOWN pUnkOuter, REFIID riid, void** ppv)
{
	HRESULT hr;
	CSpellCheckImpl             *pSpellChecker;
	pSpellChecker=new CSpellCheckImpl(); 
	hr=pSpellChecker->QueryInterface(riid, ppv);
	if (SUCCEEDED(hr)) {	
		gObjectCount++;
		return NOERROR;  
	} 	
	else {
		delete pSpellChecker;
	   *ppv=NULL;
		return E_NOINTERFACE;  
	}
}

STDMETHODIMP CSpellFactoryImpl::LockServer(BOOL fLock)
{
    if (fLock)
        gLockCount++;
    else
        gLockCount--; 
    return NOERROR;
}
