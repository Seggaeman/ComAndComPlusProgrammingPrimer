#include <olectl.h>
HINSTANCE g_hinstDll;
const char *g_RegTable[][2] = {
	{ "CLSID\\{57B7A8A0-E4D7-11d0-818D-444553540000}","Spellchecker Object"},
   	{ "CLSID\\{57B7A8A0-E4D7-11d0-818D-444553540000}\\InprocServer32",(const char*)-1}, 
   	{ "CLSID\\{57B7A8A0-E4D7-11d0-818D-444553540000}\\ProgID","Spellchecker.Object.1"},
   	{ "Spellchecker.Object.1","Spellchecker Object"},
   	{ "Spellchecker.Object.1\\CLSID","{57B7A8A0-E4D7-11d0-818D-444553540000}"}
};

STDAPI DllRegisterServer() 
{
    HRESULT hr = S_OK; 
    char szFileName[MAX_PATH]; 
    HKEY hkey;
    GetModuleFileName(g_hinstDll,szFileName,MAX_PATH);
    int nEntries = sizeof(g_RegTable)/sizeof(*g_RegTable);
for (int i=0; SUCCEEDED(hr) && i < nEntries; i++ )  {
         const char *pszKeyName	= g_RegTable[i][0];
         const char *pszValue	=g_RegTable[i][1]; 
         if (pszValue==(const char *)-1)
			   pszValue=szFileName;
         long err=RegCreateKey(HKEY_CLASSES_ROOT,pszKeyName,&hkey);
    if (err == ERROR_SUCCESS) {
		     err = RegSetValueExA(hkey,0,0,REG_SZ,(const BYTE *)pszValue,(strlen(pszValue)+1));
		     RegCloseKey(hkey);  
	    }
    if (err != ERROR_SUCCESS) {
		     DllUnregisterServer();
		     hr = SELFREG_E_CLASS; 
	    } 
    }
    return hr; 
}

STDAPI DllUnregisterServer() 
{
     HRESULT hr=S_OK;
     int nEntries = sizeof(g_RegTable)/sizeof(*g_RegTable);
for (int i = nEntries-1; i >= 0 ; i-- ) 
{
	    const char *pszKeyName	= g_RegTable[i][0];
	    long err = RegDeleteKeyA(HKEY_CLASSES_ROOT,pszKeyName);
	    if (err != ERROR_SUCCESS)
		 hr = S_FALSE; 
     }
     return hr;  
}

BOOL APIENTRY DllMain(HINSTANCE hDLLInst, DWORD fdwReason, LPVOID lpvReserved) 
{
switch (fdwReason) 
{
      case DLL_PROCESS_ATTACH :
         g_hinstDll = hDLLInst ;  
   }
   return TRUE ; 
}
