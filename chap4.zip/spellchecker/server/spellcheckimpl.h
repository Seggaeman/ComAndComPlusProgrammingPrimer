#pragma warning( disable : 4786 )
#include "spellcheck.h"  // The file generated from the idl
#include <vector>
using namespace std;
class CSpellCheckImpl : public ISpellChecker {
public:
      CSpellCheckImpl();
      ~CSpellCheckImpl();
      STDMETHOD(QueryInterface) (REFIID,void ** );
      STDMETHOD_(ULONG,AddRef) (void);
      STDMETHOD_(ULONG,Release) (void);
      STDMETHOD(CheckSpelling) (unsigned char *word,
						BOOL *isCorrect);
	  STDMETHOD(UseCustomDictionary) (unsigned char *filename); 
private:
      ULONG           m_ref;
      vector<string>	  m_dictionary;	
};
