#include <ole2.h>
class CSpellFactoryImpl :  public IClassFactory {
public:
        CSpellFactoryImpl();
        ~CSpellFactoryImpl();
        STDMETHOD(QueryInterface) (REFIID, void**ppv);
        STDMETHOD_(ULONG,AddRef) (void);
        STDMETHOD_(ULONG,Release) (void); 
        STDMETHOD(CreateInstance) (LPUNKNOWN, REFIID, 
					void **ppv);
        STDMETHOD(LockServer) (BOOL);
private:
        ULONG           m_ref;
};
