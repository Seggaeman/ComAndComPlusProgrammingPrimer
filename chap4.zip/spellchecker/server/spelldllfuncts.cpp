#include "spellcheckimpl.h"
#include "spellfactoryimpl.h"
LONG gObjectCount=0;
LONG gLockCount=0;
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid,void** ppv)
{
    HRESULT             hr;
    CSpellFactoryImpl *pObj; 
    pObj=new CSpellFactoryImpl(); 
    hr=pObj->QueryInterface(riid, ppv); 
    if (FAILED(hr)) {
        *ppv=NULL;
        delete pObj; 
    }	
    return hr;
}
STDAPI DllCanUnloadNow(void)
{
    if (gObjectCount==0 && gLockCount==0)
	return S_OK;
    else
	return S_FALSE;
}
