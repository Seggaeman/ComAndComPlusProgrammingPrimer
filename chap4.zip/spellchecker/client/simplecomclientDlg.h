// simplecomclientDlg.h : header file
//

#if !defined(AFX_SIMPLECOMCLIENTDLG_H__7BFFB1E7_FCE9_11D2_998A_94DD09C10000__INCLUDED_)
#define AFX_SIMPLECOMCLIENTDLG_H__7BFFB1E7_FCE9_11D2_998A_94DD09C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSimplecomclientDlg dialog
#include "spellcheck.h"
class CSimplecomclientDlg : public CDialog
{
// Construction
public:
	CSimplecomclientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSimplecomclientDlg)
	enum { IDD = IDD_SIMPLECOMCLIENT_DIALOG };
	CString	m_word;
	CString	m_dictionaryFile;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimplecomclientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSimplecomclientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSpellcheckerButton();
	afx_msg void OnLoadDictionaryButton();
	afx_msg void OnBrowseButton();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	ISpellChecker* pSpeller;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLECOMCLIENTDLG_H__7BFFB1E7_FCE9_11D2_998A_94DD09C10000__INCLUDED_)
