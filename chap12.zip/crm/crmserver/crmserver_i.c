
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Tue Apr 25 22:39:56 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter12\crm\crmserver\crmserver.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AXP64)

#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_ICRMWorker,0x9DB551A4,0x087C,0x41F4,0xBA,0x08,0x2D,0x81,0x3B,0xA6,0x71,0xC3);


MIDL_DEFINE_GUID(IID, IID_IMyCompensator,0x1A097D16,0xB708,0x4897,0xAD,0xC6,0x5D,0x95,0x76,0x3A,0xC9,0x33);


MIDL_DEFINE_GUID(IID, LIBID_CRMSERVERLib,0xC78D7E56,0x26A3,0x48E2,0x95,0xB5,0x4B,0xBD,0xF1,0x47,0x0D,0xCC);


MIDL_DEFINE_GUID(CLSID, CLSID_CRMWorker,0x424A34AC,0x4A6D,0x436F,0xA3,0x80,0x97,0xDC,0x0C,0x11,0xEF,0x5B);


MIDL_DEFINE_GUID(CLSID, CLSID_MyCompensator,0x5D4D88FA,0x70CC,0x40A4,0xA7,0x12,0x6A,0xA4,0xB7,0x82,0x06,0x7E);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



#endif /* !defined(_M_IA64) && !defined(_M_AXP64)*/


#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Tue Apr 25 22:39:56 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter12\crm\crmserver\crmserver.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win64 (32b run,appending), ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if defined(_M_IA64) || defined(_M_AXP64)

#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_ICRMWorker,0x9DB551A4,0x087C,0x41F4,0xBA,0x08,0x2D,0x81,0x3B,0xA6,0x71,0xC3);


MIDL_DEFINE_GUID(IID, IID_IMyCompensator,0x1A097D16,0xB708,0x4897,0xAD,0xC6,0x5D,0x95,0x76,0x3A,0xC9,0x33);


MIDL_DEFINE_GUID(IID, LIBID_CRMSERVERLib,0xC78D7E56,0x26A3,0x48E2,0x95,0xB5,0x4B,0xBD,0xF1,0x47,0x0D,0xCC);


MIDL_DEFINE_GUID(CLSID, CLSID_CRMWorker,0x424A34AC,0x4A6D,0x436F,0xA3,0x80,0x97,0xDC,0x0C,0x11,0xEF,0x5B);


MIDL_DEFINE_GUID(CLSID, CLSID_MyCompensator,0x5D4D88FA,0x70CC,0x40A4,0xA7,0x12,0x6A,0xA4,0xB7,0x82,0x06,0x7E);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



#endif /* defined(_M_IA64) || defined(_M_AXP64)*/

