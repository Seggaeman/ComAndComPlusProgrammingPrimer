// CRMWorker.h : Declaration of the CCRMWorker

#ifndef __CRMWORKER_H_
#define __CRMWORKER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCRMWorker
class ATL_NO_VTABLE CCRMWorker : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CCRMWorker, &CLSID_CRMWorker>,
	public ISupportErrorInfo,
	public IDispatchImpl<ICRMWorker, &IID_ICRMWorker, &LIBID_CRMSERVERLib>
{
public:
	CCRMWorker()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CRMWORKER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCRMWorker)
	COM_INTERFACE_ENTRY(ICRMWorker)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
public:
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ICRMWorker
public:
	STDMETHOD(WriteToFile)(/*[in]*/ BSTR strText, /*[in]*/ BSTR strPath);
};

#endif //__CRMWORKER_H_
