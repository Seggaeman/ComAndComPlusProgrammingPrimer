// MyCompensator.h : Declaration of the CMyCompensator

#ifndef __MYCOMPENSATOR_H_
#define __MYCOMPENSATOR_H_

#include "resource.h"       // main symbols
#include <fstream.h>
/////////////////////////////////////////////////////////////////////////////
// CMyCompensator
class ATL_NO_VTABLE CMyCompensator : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMyCompensator, &CLSID_MyCompensator>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMyCompensator, &IID_IMyCompensator, &LIBID_CRMSERVERLib>,
	public ICrmCompensator
{
public:
	CMyCompensator()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MYCOMPENSATOR)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyCompensator)
	COM_INTERFACE_ENTRY(IMyCompensator)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(ICrmCompensator)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMyCompensator
public:
// ICrmCompensator
	STDMETHOD(SetLogControl)(ICrmLogControl * pLogControl)
	{
		MessageBox (NULL, "ICrmCompensator::SetLogControl", "rtcrmdemo", 0) ;
		return S_OK;
	}
	STDMETHOD(BeginPrepare)()
	{
		MessageBox (NULL, "ICrmCompensator::BeginPrepare", "rtcrmdemo", 0) ;

		return S_OK;
	}
	STDMETHOD(PrepareRecord)(tagCrmLogRecordRead crmLogRec, BOOL * pfForget)
	{
		MessageBox (NULL, "ICrmCompensator::PrepareRecord", "rtcrmdemo", 0) ;
		BLOB blb=crmLogRec.blobUserData ;
		switch (crmLogRec.dwSequenceNumber)
		{
		case 1:
			mFilePath=(char*)blb.pBlobData;	
			break;
		case 2:
			mTempPath=(char *)blb.pBlobData;	
			break;
		}
		*pfForget=FALSE;
		return S_OK;
	}
	STDMETHOD(EndPrepare)(BOOL * pfOkToPrepare)
	{				
		*pfOkToPrepare = TRUE;
		return S_OK;
	}
	STDMETHOD(BeginCommit)(BOOL fRecovery)
	{
		MessageBox (NULL, "ICrmCompensator::BeginCommit", "rtcrmdemo", 0) ;

		return S_OK;
	}
	STDMETHOD(CommitRecord)(tagCrmLogRecordRead crmLogRec, BOOL * pfForget)
	{
		MessageBox (NULL, "ICrmCompensator::CommitRecord", "rtcrmdemo", 0) ;
		BLOB blb=crmLogRec.blobUserData ;
		switch (crmLogRec.dwSequenceNumber)
		{
		case 1:
			mFilePath=(char*)blb.pBlobData;	
			break;
		case 2:
			mTempPath=(char *)blb.pBlobData;	
			break;
		}
		
		return S_OK;
	}
	STDMETHOD(EndCommit)()
	{
		WIN32_FIND_DATA FindFileData;
		HANDLE hFind;
// If we committed the transaction we can delete the
// temporary file.		
		if (mTempPath.length()>0)
		{
			hFind = FindFirstFile(mTempPath, &FindFileData);

			if (hFind != INVALID_HANDLE_VALUE) 
				::DeleteFile(mTempPath);
			::FindClose(hFind);
		}
  
		return S_OK;
	}
	STDMETHOD(BeginAbort)(BOOL fRecovery)
	{

		MessageBox (NULL, "ICrmCompensator::BeginAbort", "rtcrmdemo", 0) ;

		return S_OK;
	}
	STDMETHOD(AbortRecord)(tagCrmLogRecordRead crmLogRec,	BOOL * pfForget)
	{
		MessageBox (NULL, "ICrmCompensator::AbortRecord", "rtcrmdemo", 0) ;
		BLOB blb=crmLogRec.blobUserData ;
		switch (crmLogRec.dwSequenceNumber)
		{
		case 1:
			mFilePath=(char*)blb.pBlobData;	
			break;
		case 2:
			mTempPath=(char *)blb.pBlobData;	
			break;
		}
		return S_OK;
	}
	STDMETHOD(EndAbort)()
	{
		MessageBox (NULL, "ICrmCompensator::EndAbort", "rtcrmdemo", 0) ;
// If we are aborting then we must delete the file we wrote and
// copy the original file back to the original location
		if (mFilePath.length() > 0)
			::DeleteFile(mFilePath);
		if (mTempPath.length() > 0)
			::CopyFile(mTempPath,mFilePath,FALSE);
		return S_OK;
	}

private:
	ICrmLogControl *m_pLogControl ;
	_bstr_t mFilePath;
	_bstr_t mTempPath;
};

#endif //__MYCOMPENSATOR_H_
