// MyCompensator.cpp : Implementation of CMyCompensator
#include "stdafx.h"
#include "Crmserver.h"
#include "MyCompensator.h"

/////////////////////////////////////////////////////////////////////////////
// CMyCompensator

STDMETHODIMP CMyCompensator::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMyCompensator
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}
