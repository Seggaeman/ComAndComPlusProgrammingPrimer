// CRMWorker.cpp : Implementation of CCRMWorker
#include "stdafx.h"
#include "Crmserver.h"
#include "CRMWorker.h"
#include <fstream.h>
/////////////////////////////////////////////////////////////////////////////
// CCRMWorker
const E_COULD_NOT_OPEN_FILE=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+109);
const E_COULD_NOT_WRITE_TO_FILE=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+110);
const E_ZERO_TEXT_LENGTH=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+111);
const E_ZERO_PATH_LENGTH=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+112);

STDMETHODIMP CCRMWorker::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ICRMWorker
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CCRMWorker::WriteToFile(BSTR strText, BSTR strPath)
{
	HRESULT hRetval;
	_bstr_t strDescription;
	IContextState *pContextState;
	ICrmLogControl *pCRMLogControl;
	_bstr_t path(strPath);
	_bstr_t text(strText);	
	_bstr_t tempPath;
	HANDLE hCreatedFile, hExistingFile;
	WIN32_FIND_DATA FindFileData;
	DWORD dwWritten;
	char *pTempDir, *pTempPath, *pBuf;
	BLOB blob;
	
	pContextState=0;
	if (0 == path.length())
	{
		hRetval=E_ZERO_PATH_LENGTH;
		strDescription="Zero length path was specified";
		goto CLEANUP;
	}

	if (0 == text.length())
	{
		hRetval=E_ZERO_TEXT_LENGTH;
		strDescription="Zero length text string was specified";
		goto CLEANUP;
	}

	hRetval=CoGetObjectContext(IID_IContextState,(void **)&pContextState);
	if (SUCCEEDED(hRetval))
	{
		hRetval = CoCreateInstance(CLSID_CRMClerk, NULL, CLSCTX_SERVER, 
					IID_ICrmLogControl,(void **)&pCRMLogControl);	
		if (SUCCEEDED(hRetval))
		{
			hRetval = pCRMLogControl->RegisterCompensator(L"Crmserver.MyCompensator",
						L"MyCompensator",CRMREGFLAG_ALLPHASES);
			if (FAILED(hRetval))
			{
				_com_error err(hRetval);
				strDescription=err.Description();
				goto CLEANUP;
			}
		}
		else
		{
			_com_error err(hRetval);
			strDescription=err.Description();
			goto CLEANUP;
		}
	}
	else
	{
		_com_error err(hRetval);
		strDescription=err.Description();
		goto CLEANUP;
	}
	
	blob.cbSize = path.length()+1;
	blob.pBlobData = (unsigned char *)((char *)path);
	hRetval=pCRMLogControl->WriteLogRecord(&blob,1);
	
	hExistingFile = FindFirstFile(path, &FindFileData);
// If the file that you are writing to already exists. We must copy
// this file to the temporary directory so it does not get overwritten.
	if (INVALID_HANDLE_VALUE != hExistingFile) 
	{
		pTempDir=new char[MAX_PATH];
		pTempPath=new char[MAX_PATH];
		::GetTempPath(MAX_PATH,pTempDir);
		::GetTempFileName(pTempDir,"TCT",0,pTempPath);
		blob.cbSize = strlen(pTempPath)+1;
		blob.pBlobData = (unsigned char *)pTempPath;
		hRetval=pCRMLogControl->WriteLogRecord(&blob,1);
		::CopyFile(path,pTempPath,FALSE);
		FindClose(hExistingFile);
 		delete[] pTempDir;
		delete[] pTempPath;
	}
// Make the log records durable	  
	pCRMLogControl->ForceLog();
	// If the specified file exists copy it to the temp path
		
	hCreatedFile=CreateFile(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if (hCreatedFile == INVALID_HANDLE_VALUE) 
	{ 
		strDescription=L"Could not open file";
		hRetval=E_COULD_NOT_OPEN_FILE;
	} 
	else
	{
		pBuf=new char[text.length()+1];
		wcstombs(pBuf,text,text.length()+1);
		if (!WriteFile(hCreatedFile,(const void *)pBuf,text.length()+1,&dwWritten,NULL))
		{
			strDescription=L"Could not write to file";
			hRetval=E_COULD_NOT_WRITE_TO_FILE;
		}
		::CloseHandle(hCreatedFile);		
		delete [] pBuf;
	}
CLEANUP:	
	if (0 != pContextState)
	{
		pContextState->SetDeactivateOnReturn(VARIANT_TRUE);
		if (SUCCEEDED(hRetval))
			pContextState->SetMyTransactionVote(TxCommit);
		else
			pContextState->SetMyTransactionVote(TxAbort);
		pContextState->Release();
	}

	if (SUCCEEDED(hRetval))
		return hRetval;
	else
		return Error((LPOLESTR)strDescription,IID_ICRMWorker,hRetval);
}

