
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Tue Apr 25 22:39:56 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter12\crm\crmserver\crmserver.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __crmserver_h__
#define __crmserver_h__

/* Forward Declarations */ 

#ifndef __ICRMWorker_FWD_DEFINED__
#define __ICRMWorker_FWD_DEFINED__
typedef interface ICRMWorker ICRMWorker;
#endif 	/* __ICRMWorker_FWD_DEFINED__ */


#ifndef __IMyCompensator_FWD_DEFINED__
#define __IMyCompensator_FWD_DEFINED__
typedef interface IMyCompensator IMyCompensator;
#endif 	/* __IMyCompensator_FWD_DEFINED__ */


#ifndef __CRMWorker_FWD_DEFINED__
#define __CRMWorker_FWD_DEFINED__

#ifdef __cplusplus
typedef class CRMWorker CRMWorker;
#else
typedef struct CRMWorker CRMWorker;
#endif /* __cplusplus */

#endif 	/* __CRMWorker_FWD_DEFINED__ */


#ifndef __MyCompensator_FWD_DEFINED__
#define __MyCompensator_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyCompensator MyCompensator;
#else
typedef struct MyCompensator MyCompensator;
#endif /* __cplusplus */

#endif 	/* __MyCompensator_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ICRMWorker_INTERFACE_DEFINED__
#define __ICRMWorker_INTERFACE_DEFINED__

/* interface ICRMWorker */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICRMWorker;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9DB551A4-087C-41F4-BA08-2D813BA671C3")
    ICRMWorker : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteToFile( 
            /* [in] */ BSTR strText,
            /* [in] */ BSTR strPath) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICRMWorkerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICRMWorker __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICRMWorker __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICRMWorker __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICRMWorker __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICRMWorker __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICRMWorker __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICRMWorker __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteToFile )( 
            ICRMWorker __RPC_FAR * This,
            /* [in] */ BSTR strText,
            /* [in] */ BSTR strPath);
        
        END_INTERFACE
    } ICRMWorkerVtbl;

    interface ICRMWorker
    {
        CONST_VTBL struct ICRMWorkerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICRMWorker_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICRMWorker_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICRMWorker_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICRMWorker_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICRMWorker_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICRMWorker_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICRMWorker_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICRMWorker_WriteToFile(This,strText,strPath)	\
    (This)->lpVtbl -> WriteToFile(This,strText,strPath)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICRMWorker_WriteToFile_Proxy( 
    ICRMWorker __RPC_FAR * This,
    /* [in] */ BSTR strText,
    /* [in] */ BSTR strPath);


void __RPC_STUB ICRMWorker_WriteToFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICRMWorker_INTERFACE_DEFINED__ */


#ifndef __IMyCompensator_INTERFACE_DEFINED__
#define __IMyCompensator_INTERFACE_DEFINED__

/* interface IMyCompensator */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IMyCompensator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1A097D16-B708-4897-ADC6-5D95763AC933")
    IMyCompensator : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IMyCompensatorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMyCompensator __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMyCompensator __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMyCompensator __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMyCompensator __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMyCompensator __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMyCompensator __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMyCompensator __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IMyCompensatorVtbl;

    interface IMyCompensator
    {
        CONST_VTBL struct IMyCompensatorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMyCompensator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMyCompensator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMyCompensator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMyCompensator_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMyCompensator_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMyCompensator_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMyCompensator_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IMyCompensator_INTERFACE_DEFINED__ */



#ifndef __CRMSERVERLib_LIBRARY_DEFINED__
#define __CRMSERVERLib_LIBRARY_DEFINED__

/* library CRMSERVERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_CRMSERVERLib;

EXTERN_C const CLSID CLSID_CRMWorker;

#ifdef __cplusplus

class DECLSPEC_UUID("424A34AC-4A6D-436F-A380-97DC0C11EF5B")
CRMWorker;
#endif

EXTERN_C const CLSID CLSID_MyCompensator;

#ifdef __cplusplus

class DECLSPEC_UUID("5D4D88FA-70CC-40A4-A712-6AA4B782067E")
MyCompensator;
#endif
#endif /* __CRMSERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


