#ifndef STOCKEVENTINFO_H
#define STOCKEVENTINFO_H
#include "stockserver.h"
// This class encapsulates all the information required for a stock.
// Using a class to hold all the information for a particular stock
// is a much better design than the one shown in chapter 8. Simplicity
// and ease of explanation drove the design for the stock server in chapter
// 8. Here I did it right!
class StockEventInfo
{
public:
	StockEventInfo(IStockEvent *evt,BSTR ticker,float currentPrice,short propensity)
	{
// We must create a copy of the BSTR that is passed in
		m_Ticker=::SysAllocString(ticker);
		m_CurrentPrice=currentPrice;
		m_propensityToRise=propensity;
		m_Evt=evt;
// Very important that we AddRef the outbound interface pointer
		if (m_Evt != 0)
			m_Evt->AddRef();
		m_marshaledInterface=0;
		::CoMarshalInterThreadInterfaceInStream(IID_IStockEvent,
			m_Evt,&m_pStream);
	}
	~StockEventInfo()
	{
		if (m_Evt != 0)
			m_Evt->Release();
		if (m_marshaledInterface != 0)
			m_marshaledInterface->Release();
		::SysFreeString(m_Ticker);
	}
	IStockEvent* GetMarshaledInterface()
	{
	// Unmarshal the interface pointer, once only.
		if (0 == m_marshaledInterface) 
			::CoGetInterfaceAndReleaseStream(m_pStream,IID_IStockEvent,
				(void **)&m_marshaledInterface);
		return m_marshaledInterface;
	}
	IStockEvent *m_Evt;
	float m_CurrentPrice;
	short m_propensityToRise;
	BSTR m_Ticker;
private:
// Make the marshaled interface private so you have to
// get it through the GetMarshaledInterface	function
	IStockEvent *m_marshaledInterface;		
	IStream *m_pStream;
};
#endif // STOCKEVENTINFO_H