// StockMonitor.cpp : Implementation of CStockMonitor
#include "stdafx.h"
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "Stockserver.h"
#include "StockMonitor.h"
#include "stockevent.h"
/////////////////////////////////////////////////////////////////////////////
// CStockMonitor
const E_STOCKNOTFOUND=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+103);
const E_STOCKEXISTSALREADY=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+104);
DWORD WINAPI threadProc(void *pv)
{
	DWORD retval;
	CStockMonitor *stockMonitor;
	HRESULT hRes;
	hRes = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	if (SUCCEEDED(hRes))
	{
		stockMonitor=(CStockMonitor*)pv;
		while (!stockMonitor->m_bHaltThread)
		{
			stockMonitor->MonitorStocks();
			::Sleep(3000);
		}
		CoUninitialize();
		SetEvent(stockMonitor->m_hEventShutdown);
		retval=0;
	}
	else
		retval=2;
	return retval;
}

STDMETHODIMP CStockMonitor::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IStockMonitor
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

void CStockMonitor::MonitorStocks()
{
	short propensityValue, numStocks, randomNumber, index;
	CComBSTR ticker;
	float oldPrice, newPrice;
	StockEventInfo *pStockInfo;
	IStockEvent *pEvt;

	ObjectLock lock(this);
	numStocks=m_StockServerMap.size();
	if (numStocks > 0)
	{
		randomNumber=rand();
		index=randomNumber % numStocks;
		pStockInfo=m_StockServerMap[index];
		oldPrice=pStockInfo->m_CurrentPrice;
		propensityValue=pStockInfo->m_propensityToRise;
		if ((randomNumber % 100) < propensityValue)
			newPrice=oldPrice+4.0;
		else
		{
			if (oldPrice > 2.0)
				newPrice=oldPrice-2.0;
		}
		pStockInfo->m_CurrentPrice=newPrice;
		pEvt=pStockInfo->GetMarshaledInterface();
		ticker=pStockInfo->m_Ticker;
		pEvt->PriceChange(ticker,newPrice,oldPrice);
	}
}

STDMETHODIMP CStockMonitor::Advise(IStockEvent *evt,BSTR ticker, float price, short propensity, short *cookie)
{
	StockEventInfo *pEventInfo=new StockEventInfo(evt,ticker,price,propensity);
	m_StockServerMap.insert(map<short,StockEventInfo*>::value_type(m_currentCookieValue,pEventInfo));
	m_currentCookieValue++;
	return S_OK;
}

void CStockMonitor::UnregisterAllClientCallBacks()
{
	map<short,StockEventInfo*>::iterator iter;
	for (iter=m_StockServerMap.begin();iter!=m_StockServerMap.end();iter++)  
	{
		StockEventInfo *stockMonitor=(*iter).second;
		delete stockMonitor;
	}
	m_StockServerMap.clear();
}

STDMETHODIMP CStockMonitor::Unadvise(short cookie)
{
	HRESULT hRes;
	StockEventInfo *stockMonitor;
	map<short,StockEventInfo*>::iterator iter;
	ObjectLock lock(this);
	iter=m_StockServerMap.find(cookie);
	if (iter!=m_StockServerMap.end())
	{
		stockMonitor=(*iter).second;
		delete stockMonitor;	
		m_StockServerMap.erase(cookie);
		hRes=S_OK;
	}
	else
		hRes=Error(_T("There is no stock monitor with this index"),IID_IStockMonitor,E_STOCKNOTFOUND);
	return hRes;
}
