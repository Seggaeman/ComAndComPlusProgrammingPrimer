// StockMonitor.h : Declaration of the CStockMonitor

#ifndef __STOCKMONITOR_H_
#define __STOCKMONITOR_H_

#include "resource.h"       // main symbols
#include "stockserverCP.h"
#include <map>
#include "stockpricer.h"	// Added by ClassView
using namespace std;
class StockEventInfo;
/////////////////////////////////////////////////////////////////////////////
// CStockMonitor
DWORD WINAPI threadProc(void *pv);
class ATL_NO_VTABLE CStockMonitor : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CStockMonitor, &CLSID_StockMonitor>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CStockMonitor>,
	public IDispatchImpl<IStockMonitor, &IID_IStockMonitor, &LIBID_STOCKSERVERLib>,
	public CProxy_IStockMonitorEvents< CStockMonitor >
{
public:
	CStockMonitor()
	{		
		DWORD threadID;
		m_CurrentCookieValue=0;
		m_bHaltThread = false;
		m_hThreadHandle=CreateThread(0,0,threadProc,this,0,&threadID);
	}

DECLARE_REGISTRY_RESOURCEID(IDR_STOCKMONITOR)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStockMonitor)
	COM_INTERFACE_ENTRY(IStockMonitor)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CStockMonitor)
CONNECTION_POINT_ENTRY(DIID__IStockMonitorEvents)
END_CONNECTION_POINT_MAP()


// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IStockMonitor
public:
	STDMETHOD(Unadvise)(/*[in]*/ short cookie);
	STDMETHOD(Advise)(/*[in]*/ IStockEvent *evt,/*[in]*/ BSTR ticker, /*[in]*/ float price, /*[in]*/ short propensity, /*[out,retval]*/ short *cookie);	
	void UnregisterAllClientCallBacks();
	void MonitorStocks();
	void FinalRelease()
	{
		ShutdownGracefully();
	}
	static void InitializeGIT()
	{
		CoCreateInstance(CLSID_StdGlobalInterfaceTable,0,CLSCTX_INPROC_SERVER,IID_IGlobalInterfaceTable,(void **)&pGIT);
	}
	static void ReleaseGIT()
	{
		if (pGIT!=0)
			pGIT->Release();
	}
	bool m_bHaltThread;
	HANDLE m_hEventShutdown;
private:	
	static IGlobalInterfaceTable *pGIT;
	void ShutdownGracefully();
	map<short,StockEventInfo*> m_StockServerMap;
	HANDLE m_hThreadHandle;
	short m_CurrentCookieValue;	
};

#endif //__STOCKMONITOR_H_
