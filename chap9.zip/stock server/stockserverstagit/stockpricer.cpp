#include <stdafx.h>
#include "stockpricer.h"
StockPricer::StockPricer()
{
	m_fCurrentOtherPrice=65.0;
	m_fCurrentMicrosoftPrice=135.0;
	m_fCurrentLogiconPrice=45.0;
	m_fCurrentIBMPrice=95.0;
}
float StockPricer::GetCurrentPrice(BSTR ticker)
{
// This is a trivial implementation it wouldn't be terribly difficult to change this
// implementation so that it queried a web site for real stock information.
	float currentPrice;
	CComBSTR bstrTicker(ticker);
	if (bstrTicker=="MSFT") 
	{
		m_fCurrentMicrosoftPrice+=.25f;
		currentPrice=m_fCurrentMicrosoftPrice;
	}
	else if (bstrTicker=="IBM") 
	{
		m_fCurrentIBMPrice+=.15f;
		currentPrice=m_fCurrentIBMPrice;
	}
	else if (bstrTicker=="LGN")
	{
		m_fCurrentLogiconPrice+=.05f;
		currentPrice=m_fCurrentLogiconPrice;
	}
	else
	{
		m_fCurrentOtherPrice+=.1f;
		currentPrice=m_fCurrentOtherPrice;
	}
	return currentPrice;
}
