#ifndef STOCKEVENTMANAGER_H
#define STOCKEVENTMANAGER_H
#include <map>
using namespace std;
class StockEventInfo;
class StockEventManager
{
public:
	float GetCurrentPrice(BSTR ticker);
	void MonitorStocks();
	StockEventManager();
	~StockEventManager();
	short RegisterClientCallBack(StockEventInfo* pStockData);
	bool UnregisterClientCallBack(short cookie);
	void UnregisterAllClientCallBacks();
	bool TempAreaHasEntries();
	void CheckForAndMarshallInterfaces();
	bool m_bHaltThread;
	HANDLE m_hEventShutdown;	
private:	
	CRITICAL_SECTION m_StockEventManagerCriticalSection;
	HANDLE m_hThreadHandle;
	short m_CurrentCookieValue;	
	bool m_bThreadStarted;
	float m_fCurrentOtherPrice;
	float m_fCurrentMicrosoftPrice;
	float m_fCurrentIBMPrice;
	float m_fCurrentLogiconPrice;
};
#endif // STOCKEVENTMANAGER_H