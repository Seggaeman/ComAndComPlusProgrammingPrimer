
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Mon Apr 03 23:46:05 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter9\stock server\stockserverstagit\stockserver.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __stockserver_h__
#define __stockserver_h__

/* Forward Declarations */ 

#ifndef __IStockEvent_FWD_DEFINED__
#define __IStockEvent_FWD_DEFINED__
typedef interface IStockEvent IStockEvent;
#endif 	/* __IStockEvent_FWD_DEFINED__ */


#ifndef __IStockMonitor_FWD_DEFINED__
#define __IStockMonitor_FWD_DEFINED__
typedef interface IStockMonitor IStockMonitor;
#endif 	/* __IStockMonitor_FWD_DEFINED__ */


#ifndef ___IStockMonitorEvents_FWD_DEFINED__
#define ___IStockMonitorEvents_FWD_DEFINED__
typedef interface _IStockMonitorEvents _IStockMonitorEvents;
#endif 	/* ___IStockMonitorEvents_FWD_DEFINED__ */


#ifndef __StockMonitor_FWD_DEFINED__
#define __StockMonitor_FWD_DEFINED__

#ifdef __cplusplus
typedef class StockMonitor StockMonitor;
#else
typedef struct StockMonitor StockMonitor;
#endif /* __cplusplus */

#endif 	/* __StockMonitor_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IStockEvent_INTERFACE_DEFINED__
#define __IStockEvent_INTERFACE_DEFINED__

/* interface IStockEvent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStockEvent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D37658C0-2728-11d3-998A-E0EC08C10000")
    IStockEvent : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE PriceChange( 
            /* [in] */ BSTR ticker,
            /* [in] */ float newPrice,
            /* [in] */ float oldPrice) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MonitorInitiated( 
            /* [in] */ BSTR ticker,
            /* [in] */ float currentPrice) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStockEventVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStockEvent __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStockEvent __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IStockEvent __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PriceChange )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ BSTR ticker,
            /* [in] */ float newPrice,
            /* [in] */ float oldPrice);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MonitorInitiated )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ BSTR ticker,
            /* [in] */ float currentPrice);
        
        END_INTERFACE
    } IStockEventVtbl;

    interface IStockEvent
    {
        CONST_VTBL struct IStockEventVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStockEvent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStockEvent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStockEvent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStockEvent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStockEvent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStockEvent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStockEvent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IStockEvent_PriceChange(This,ticker,newPrice,oldPrice)	\
    (This)->lpVtbl -> PriceChange(This,ticker,newPrice,oldPrice)

#define IStockEvent_MonitorInitiated(This,ticker,currentPrice)	\
    (This)->lpVtbl -> MonitorInitiated(This,ticker,currentPrice)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStockEvent_PriceChange_Proxy( 
    IStockEvent __RPC_FAR * This,
    /* [in] */ BSTR ticker,
    /* [in] */ float newPrice,
    /* [in] */ float oldPrice);


void __RPC_STUB IStockEvent_PriceChange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStockEvent_MonitorInitiated_Proxy( 
    IStockEvent __RPC_FAR * This,
    /* [in] */ BSTR ticker,
    /* [in] */ float currentPrice);


void __RPC_STUB IStockEvent_MonitorInitiated_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStockEvent_INTERFACE_DEFINED__ */


#ifndef __IStockMonitor_INTERFACE_DEFINED__
#define __IStockMonitor_INTERFACE_DEFINED__

/* interface IStockMonitor */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStockMonitor;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4506CE8D-2A84-11D3-998A-E0EC08C10000")
    IStockMonitor : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Advise( 
            /* [in] */ IStockEvent __RPC_FAR *evt,
            /* [in] */ BSTR ticker,
            /* [in] */ float price,
            /* [in] */ short propensity,
            /* [retval][out] */ short __RPC_FAR *cookie) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Unadvise( 
            /* [in] */ short cookie) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStockMonitorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStockMonitor __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStockMonitor __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStockMonitor __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IStockMonitor __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IStockMonitor __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IStockMonitor __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IStockMonitor __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Advise )( 
            IStockMonitor __RPC_FAR * This,
            /* [in] */ IStockEvent __RPC_FAR *evt,
            /* [in] */ BSTR ticker,
            /* [in] */ float price,
            /* [in] */ short propensity,
            /* [retval][out] */ short __RPC_FAR *cookie);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Unadvise )( 
            IStockMonitor __RPC_FAR * This,
            /* [in] */ short cookie);
        
        END_INTERFACE
    } IStockMonitorVtbl;

    interface IStockMonitor
    {
        CONST_VTBL struct IStockMonitorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStockMonitor_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStockMonitor_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStockMonitor_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStockMonitor_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStockMonitor_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStockMonitor_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStockMonitor_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IStockMonitor_Advise(This,evt,ticker,price,propensity,cookie)	\
    (This)->lpVtbl -> Advise(This,evt,ticker,price,propensity,cookie)

#define IStockMonitor_Unadvise(This,cookie)	\
    (This)->lpVtbl -> Unadvise(This,cookie)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStockMonitor_Advise_Proxy( 
    IStockMonitor __RPC_FAR * This,
    /* [in] */ IStockEvent __RPC_FAR *evt,
    /* [in] */ BSTR ticker,
    /* [in] */ float price,
    /* [in] */ short propensity,
    /* [retval][out] */ short __RPC_FAR *cookie);


void __RPC_STUB IStockMonitor_Advise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStockMonitor_Unadvise_Proxy( 
    IStockMonitor __RPC_FAR * This,
    /* [in] */ short cookie);


void __RPC_STUB IStockMonitor_Unadvise_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStockMonitor_INTERFACE_DEFINED__ */



#ifndef __STOCKSERVERLib_LIBRARY_DEFINED__
#define __STOCKSERVERLib_LIBRARY_DEFINED__

/* library STOCKSERVERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_STOCKSERVERLib;

#ifndef ___IStockMonitorEvents_DISPINTERFACE_DEFINED__
#define ___IStockMonitorEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IStockMonitorEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IStockMonitorEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("4506CE8F-2A84-11D3-998A-E0EC08C10000")
    _IStockMonitorEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IStockMonitorEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IStockMonitorEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IStockMonitorEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IStockMonitorEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IStockMonitorEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IStockMonitorEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IStockMonitorEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IStockMonitorEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IStockMonitorEventsVtbl;

    interface _IStockMonitorEvents
    {
        CONST_VTBL struct _IStockMonitorEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IStockMonitorEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IStockMonitorEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IStockMonitorEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IStockMonitorEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IStockMonitorEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IStockMonitorEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IStockMonitorEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IStockMonitorEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_StockMonitor;

#ifdef __cplusplus

class DECLSPEC_UUID("5B4AB349-2424-4741-BFF1-A48B1CE0A670")
StockMonitor;
#endif
#endif /* __STOCKSERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


