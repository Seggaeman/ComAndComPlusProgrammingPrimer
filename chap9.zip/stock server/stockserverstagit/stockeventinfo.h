#ifndef STOCKEVENTINFO_H
#define STOCKEVENTINFO_H
#include "stockserver.h"
class StockEventInfo
{
public:
	StockEventInfo(DWORD gitCookie,BSTR ticker,float currentPrice,short propensity)
	{
// We must create a copy of the BSTR that is passed in
		m_gitCookie=gitCookie;
		m_Ticker=::SysAllocString(ticker);
		m_CurrentPrice=currentPrice;
		m_propensityToRise=propensity;
	}
	~StockEventInfo()
	{
		::SysFreeString(m_Ticker);
	}
	DWORD m_gitCookie;
	float m_CurrentPrice;
	short m_propensityToRise;
	BSTR m_Ticker;
};
#endif // STOCKEVENTINFO_H