#ifndef STOCK_PRICER_H
#define STOCK_PRICER_H
class StockPricer
{
public:
	StockPricer();
	float GetCurrentPrice(BSTR ticker);
private:
	float m_fCurrentOtherPrice;
	float m_fCurrentMicrosoftPrice;
	float m_fCurrentIBMPrice;
	float m_fCurrentLogiconPrice;
};
#endif // STOCK_PRICER_H