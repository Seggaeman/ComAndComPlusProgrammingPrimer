#include "stdafx.h"
#include <math.h>
#include "stockeventmanager.h"
#include "stockeventinfo.h"
#include "stockmonitor.h"
DWORD WINAPI threadProc(void *pv)
{
	StockEventManager *stockMgr=(StockEventManager*)pv;
	while (!stockMgr->m_bHaltThread)
	{
		stockMgr->MonitorStocks();
		::Sleep(2000);
	}
	SetEvent(stockMgr->m_hEventShutdown);
	return 0;
}
StockEventManager::StockEventManager()
{	
	::InitializeCriticalSection(&m_StockEventManagerCriticalSection);	
	m_CurrentCookieValue=0;
	m_fCurrentOtherPrice=65.0;
	m_fCurrentMicrosoftPrice=135.0;
	m_fCurrentLogiconPrice=45.0;
	m_fCurrentIBMPrice=95.0;
	m_bThreadStarted = false;
	m_bHaltThread = false;
}

StockEventManager::~StockEventManager()
{	
	DWORD aWord;
	aWord=1;	
	if (m_bThreadStarted)
	{
		m_hEventShutdown = CreateEvent(NULL, false, false, NULL);
		m_bHaltThread=true;	
		WaitForSingleObject(m_hEventShutdown, INFINITE);
		TerminateThread(m_hThreadHandle,aWord);
	}
	UnregisterAllClientCallBacks();
	::DeleteCriticalSection(&m_StockEventManagerCriticalSection);	
}

void StockEventManager::MonitorStocks()
{
	HRESULT hRes;
	IStockEvent *pEvt;
	CStockMonitor *pObj;
	float oldPrice, currentPrice, delta;
	::EnterCriticalSection(&m_StockEventManagerCriticalSection);
	map<short,StockEventInfo*>::iterator iter;
	for (iter=m_StockServerMap.begin();iter!=m_StockServerMap.end();iter++)  
	{
		StockEventInfo *stockMonitor=(*iter).second;
		oldPrice=stockMonitor->m_CurrentPrice;
		currentPrice=GetCurrentPrice(stockMonitor->m_Ticker);
		delta=currentPrice-oldPrice;
		if (fabs(delta) > stockMonitor->m_Delta)
		{
			pEvt=stockMonitor->m_Evt;
			pObj=stockMonitor->m_Obj;
			if (pEvt != 0 )
				hRes=pEvt->PriceChange(stockMonitor->m_Ticker,currentPrice,oldPrice);
			else
				hRes=pObj->Fire_PriceChange(stockMonitor->m_Ticker,currentPrice,oldPrice);
			stockMonitor->m_CurrentPrice=currentPrice;			
		}
	}
	::LeaveCriticalSection(&m_StockEventManagerCriticalSection);
}

float StockEventManager::GetCurrentPrice(BSTR ticker)
{
// This is a trivial implementation it wouldn't be terribly difficult to change this
// implementation so that it queried a web site for real stock information.
	float currentPrice;
	CComBSTR bstrTicker(ticker);
	::EnterCriticalSection(&m_StockEventManagerCriticalSection);
	if (bstrTicker=="MSFT") 
	{
		m_fCurrentMicrosoftPrice+=.25f;
		currentPrice=m_fCurrentMicrosoftPrice;
	}
	else if (bstrTicker=="IBM") 
	{
		m_fCurrentIBMPrice+=.15f;
		currentPrice=m_fCurrentIBMPrice;
	}
	else if (bstrTicker=="LGN")
	{
		m_fCurrentLogiconPrice+=.05f;
		currentPrice=m_fCurrentLogiconPrice;
	}
	else
	{
		m_fCurrentOtherPrice+=.1f;
		currentPrice=m_fCurrentOtherPrice;
	}
	::LeaveCriticalSection(&m_StockEventManagerCriticalSection);
	return currentPrice;
}



bool StockEventManager::UnregisterClientCallBack(short cookie)
{
	bool success;
	StockEventInfo *stockMonitor;
	map<short,StockEventInfo*>::iterator iter;
	::EnterCriticalSection(&m_StockEventManagerCriticalSection);	
	iter=m_StockServerMap.find(cookie);
	if (iter!=m_StockServerMap.end())
	{
		stockMonitor=(*iter).second;
		delete stockMonitor;	
		m_StockServerMap.erase(cookie);
		success=true;
	}
	else
		success=false;
	::LeaveCriticalSection(&m_StockEventManagerCriticalSection);
	return success;
}

void StockEventManager::UnregisterAllClientCallBacks()
{
	map<short,StockEventInfo*>::iterator iter;
	::EnterCriticalSection(&m_StockEventManagerCriticalSection);	
	for (iter=m_StockServerMap.begin();iter!=m_StockServerMap.end();iter++)  
	{
		StockEventInfo *stockMonitor=(*iter).second;
		delete stockMonitor;
	}
	m_StockServerMap.clear();
	::LeaveCriticalSection(&m_StockEventManagerCriticalSection);
}

bool StockEventManager::TempAreaHasEntries()
{
	// Only the worker thread will use this collection so there is no need to use a critical section
	return (m_tempMap.size()>0);
}
void StockEventManager::CheckForAndMarshallInterfaces()
{
	
}