// StockMonitor.cpp : Implementation of CStockMonitor
#include "stdafx.h"
#include <math.h>
#include "Stockserver.h"
#include "StockMonitor.h"
#include "stockeventinfo.h"
/////////////////////////////////////////////////////////////////////////////
// CStockMonitor
IGlobalInterfaceTable *CStockMonitor::pGIT;
const E_STOCKMONITORNOTFOUND=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+103);
DWORD WINAPI threadProc(void *pv)
{
	HRESULT hRes = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	CStockMonitor *stockMonitor=(CStockMonitor*)pv;
	while (!stockMonitor->m_bHaltThread)
	{
		stockMonitor->MonitorStocks();
		::Sleep(2000);
	}
	CoUninitialize();
	SetEvent(stockMonitor->m_hEventShutdown);
	return 0;
}

STDMETHODIMP CStockMonitor::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IStockMonitor
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CStockMonitor::Advise(IStockEvent *evt,BSTR ticker, float price, short propensity, short *cookie)
{
	DWORD gitCookie;
	pGIT->RegisterInterfaceInGlobal(evt,IID_IStockEvent,&gitCookie);
	StockEventInfo *pEventInfo=new StockEventInfo(gitCookie,ticker,price,propensity);
	Fire_MonitorInitiated(ticker,price);
	ObjectLock lock(this);
	m_StockServerMap.insert(map<short,StockEventInfo*>::value_type(m_CurrentCookieValue,pEventInfo));
	*cookie=m_CurrentCookieValue;
	m_CurrentCookieValue++;	
	return S_OK;
}

STDMETHODIMP CStockMonitor::Unadvise(short cookie)
{
	StockEventInfo *stockMonitor;
	map<short,StockEventInfo*>::iterator iter;
	ObjectLock lock(this);
	iter=m_StockServerMap.find(cookie);
	if (iter!=m_StockServerMap.end())
	{
		stockMonitor=(*iter).second;
		pGIT->RevokeInterfaceFromGlobal(stockMonitor->m_gitCookie);
		delete stockMonitor;	
		m_StockServerMap.erase(cookie);
		return S_OK;
	}
	else
		return Error(_T("There is no stock monitor with this index"),IID_IStockMonitor,E_STOCKMONITORNOTFOUND);
}

void CStockMonitor::MonitorStocks()
{
	HRESULT hRes;
	IStockEvent *pEvt;
	short propensityValue, numStocks, randomNumber, index;
	float oldPrice, newPrice;	
	StockEventInfo *pStockInfo;

	ObjectLock lock(this);

	numStocks=m_StockServerMap.size();
	if (numStocks > 0)
	{
		randomNumber=rand();
		index=randomNumber % numStocks;
		pStockInfo=m_StockServerMap[index];
		oldPrice=pStockInfo->m_CurrentPrice;
		propensityValue=pStockInfo->m_propensityToRise;
		if ((randomNumber % 100) < propensityValue)
			newPrice=oldPrice+4.0;
		else
		{
			if (oldPrice > 2.0)
				newPrice=oldPrice-2.0;
		}
		pStockInfo->m_CurrentPrice=newPrice;
		pGIT->GetInterfaceFromGlobal(pStockInfo->m_gitCookie,IID_IStockEvent,(void **)&pEvt);
		hRes=pEvt->PriceChange(pStockInfo->m_Ticker,newPrice,oldPrice);
	}
}

void CStockMonitor::UnregisterAllClientCallBacks()
{
	map<short,StockEventInfo*>::iterator iter;
	for (iter=m_StockServerMap.begin();iter!=m_StockServerMap.end();iter++)  
	{
		StockEventInfo *stockMonitor=(*iter).second;
		pGIT->RevokeInterfaceFromGlobal(stockMonitor->m_gitCookie);
		delete stockMonitor;
	}
	m_StockServerMap.clear();
}

void CStockMonitor::ShutdownGracefully()
{
	DWORD aWord;
	aWord=1;
	m_hEventShutdown = CreateEvent(NULL, false, false, NULL);
	m_bHaltThread=true;	
	WaitForSingleObject(m_hEventShutdown, INFINITE);
	TerminateThread(m_hThreadHandle,aWord);
	
	UnregisterAllClientCallBacks();
}


