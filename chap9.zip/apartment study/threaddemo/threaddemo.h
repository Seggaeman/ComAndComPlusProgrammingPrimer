/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Dec 20 01:05:00 1999
 */
/* Compiler settings for C:\Alan\books\vcppbook\DEMOS\chapter9\threaddemo\threaddemo.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __threaddemo_h__
#define __threaddemo_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IThreadView_FWD_DEFINED__
#define __IThreadView_FWD_DEFINED__
typedef interface IThreadView IThreadView;
#endif 	/* __IThreadView_FWD_DEFINED__ */


#ifndef __SingleThreaded_FWD_DEFINED__
#define __SingleThreaded_FWD_DEFINED__

#ifdef __cplusplus
typedef class SingleThreaded SingleThreaded;
#else
typedef struct SingleThreaded SingleThreaded;
#endif /* __cplusplus */

#endif 	/* __SingleThreaded_FWD_DEFINED__ */


#ifndef __ApartmentThreaded_FWD_DEFINED__
#define __ApartmentThreaded_FWD_DEFINED__

#ifdef __cplusplus
typedef class ApartmentThreaded ApartmentThreaded;
#else
typedef struct ApartmentThreaded ApartmentThreaded;
#endif /* __cplusplus */

#endif 	/* __ApartmentThreaded_FWD_DEFINED__ */


#ifndef __FreeThreaded_FWD_DEFINED__
#define __FreeThreaded_FWD_DEFINED__

#ifdef __cplusplus
typedef class FreeThreaded FreeThreaded;
#else
typedef struct FreeThreaded FreeThreaded;
#endif /* __cplusplus */

#endif 	/* __FreeThreaded_FWD_DEFINED__ */


#ifndef __BothThreaded_FWD_DEFINED__
#define __BothThreaded_FWD_DEFINED__

#ifdef __cplusplus
typedef class BothThreaded BothThreaded;
#else
typedef struct BothThreaded BothThreaded;
#endif /* __cplusplus */

#endif 	/* __BothThreaded_FWD_DEFINED__ */


#ifndef __NeutralThreaded_FWD_DEFINED__
#define __NeutralThreaded_FWD_DEFINED__

#ifdef __cplusplus
typedef class NeutralThreaded NeutralThreaded;
#else
typedef struct NeutralThreaded NeutralThreaded;
#endif /* __cplusplus */

#endif 	/* __NeutralThreaded_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IThreadView_INTERFACE_DEFINED__
#define __IThreadView_INTERFACE_DEFINED__

/* interface IThreadView */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IThreadView;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0663732D-314D-11D3-998A-E0EC08C10000")
    IThreadView : public IUnknown
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_ThreadID( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IThreadViewVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IThreadView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IThreadView __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IThreadView __RPC_FAR * This);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ThreadID )( 
            IThreadView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IThreadViewVtbl;

    interface IThreadView
    {
        CONST_VTBL struct IThreadViewVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThreadView_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IThreadView_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IThreadView_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IThreadView_get_ThreadID(This,pVal)	\
    (This)->lpVtbl -> get_ThreadID(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IThreadView_get_ThreadID_Proxy( 
    IThreadView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IThreadView_get_ThreadID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IThreadView_INTERFACE_DEFINED__ */



#ifndef __THREADDEMOLib_LIBRARY_DEFINED__
#define __THREADDEMOLib_LIBRARY_DEFINED__

/* library THREADDEMOLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_THREADDEMOLib;

EXTERN_C const CLSID CLSID_SingleThreaded;

#ifdef __cplusplus

class DECLSPEC_UUID("0663732E-314D-11D3-998A-E0EC08C10000")
SingleThreaded;
#endif

EXTERN_C const CLSID CLSID_ApartmentThreaded;

#ifdef __cplusplus

class DECLSPEC_UUID("06637330-314D-11D3-998A-E0EC08C10000")
ApartmentThreaded;
#endif

EXTERN_C const CLSID CLSID_FreeThreaded;

#ifdef __cplusplus

class DECLSPEC_UUID("06637332-314D-11D3-998A-E0EC08C10000")
FreeThreaded;
#endif

EXTERN_C const CLSID CLSID_BothThreaded;

#ifdef __cplusplus

class DECLSPEC_UUID("06637334-314D-11D3-998A-E0EC08C10000")
BothThreaded;
#endif

EXTERN_C const CLSID CLSID_NeutralThreaded;

#ifdef __cplusplus

class DECLSPEC_UUID("79BAE472-2BEA-4673-8277-76EB2E546BB8")
NeutralThreaded;
#endif
#endif /* __THREADDEMOLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
