// SingleThreaded.h : Declaration of the CSingleThreaded

#ifndef __SINGLETHREADED_H_
#define __SINGLETHREADED_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSingleThreaded
class ATL_NO_VTABLE CSingleThreaded : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSingleThreaded, &CLSID_SingleThreaded>,
	public ISupportErrorInfo,
	public IThreadView
{
public:
	CSingleThreaded()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SINGLETHREADED)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSingleThreaded)
	COM_INTERFACE_ENTRY(IThreadView)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IThreadView
public:
	STDMETHOD(get_ThreadID)(/*[out, retval]*/ long *pVal);
};

#endif //__SINGLETHREADED_H_
