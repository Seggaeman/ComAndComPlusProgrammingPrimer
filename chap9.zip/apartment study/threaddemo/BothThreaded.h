// BothThreaded.h : Declaration of the CBothThreaded

#ifndef __BOTHTHREADED_H_
#define __BOTHTHREADED_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CBothThreaded
class ATL_NO_VTABLE CBothThreaded : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CBothThreaded, &CLSID_BothThreaded>,
	public ISupportErrorInfo,
	public IThreadView
{
public:
	CBothThreaded()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_BOTHTHREADED)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CBothThreaded)
	COM_INTERFACE_ENTRY(IThreadView)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IThreadView
public:
	STDMETHOD(get_ThreadID)(/*[out, retval]*/ long *pVal);
};

#endif //__BOTHTHREADED_H_
