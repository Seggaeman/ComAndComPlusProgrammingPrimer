// ApartmentThreaded.h : Declaration of the CApartmentThreaded

#ifndef __APARTMENTTHREADED_H_
#define __APARTMENTTHREADED_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CApartmentThreaded
class ATL_NO_VTABLE CApartmentThreaded : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CApartmentThreaded, &CLSID_ApartmentThreaded>,
	public ISupportErrorInfo,
	public IThreadView
{
public:
	CApartmentThreaded()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_APARTMENTTHREADED)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CApartmentThreaded)
	COM_INTERFACE_ENTRY(IThreadView)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IThreadView
public:
	STDMETHOD(get_ThreadID)(/*[out, retval]*/ long *pVal);
};

#endif //__APARTMENTTHREADED_H_
