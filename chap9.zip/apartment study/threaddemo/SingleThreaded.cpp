// SingleThreaded.cpp : Implementation of CSingleThreaded
#include "stdafx.h"
#include "Threaddemo.h"
#include "SingleThreaded.h"

/////////////////////////////////////////////////////////////////////////////
// CSingleThreaded

STDMETHODIMP CSingleThreaded::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IThreadView
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSingleThreaded::get_ThreadID(long *pVal)
{
	*pVal=::GetCurrentThreadId();
	return S_OK;
}
