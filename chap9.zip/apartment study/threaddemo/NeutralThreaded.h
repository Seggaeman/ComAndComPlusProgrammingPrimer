// CNeutralThreaded.h : Declaration of the CCNeutralThreaded

#ifndef __NEUTRALTHREADED_H_
#define __NEUTRALTHREADED_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCNeutralThreaded
class ATL_NO_VTABLE CNeutralThreaded : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CNeutralThreaded, &CLSID_NeutralThreaded>,
	public ISupportErrorInfo,
	public IThreadView
{
public:
	CNeutralThreaded()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CNEUTRALTHREADED)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CNeutralThreaded)
	COM_INTERFACE_ENTRY(IThreadView)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IThreadView
public:
	STDMETHOD(get_ThreadID)(/*[out, retval]*/ long *pVal);
};

#endif //__NEUTRALTHREADED_H_
