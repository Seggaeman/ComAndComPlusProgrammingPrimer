// FreeThreaded.cpp : Implementation of CFreeThreaded
#include "stdafx.h"
#include "Threaddemo.h"
#include "FreeThreaded.h"

/////////////////////////////////////////////////////////////////////////////
// CFreeThreaded

STDMETHODIMP CFreeThreaded::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IThreadView
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CFreeThreaded::get_ThreadID(long *pVal)
{
	*pVal=::GetCurrentThreadId();
	return S_OK;
}
