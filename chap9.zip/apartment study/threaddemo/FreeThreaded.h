// FreeThreaded.h : Declaration of the CFreeThreaded

#ifndef __FREETHREADED_H_
#define __FREETHREADED_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFreeThreaded
class ATL_NO_VTABLE CFreeThreaded : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CFreeThreaded, &CLSID_FreeThreaded>,
	public ISupportErrorInfo,
	public IThreadView
{
public:
	CFreeThreaded()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_FREETHREADED)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CFreeThreaded)
	COM_INTERFACE_ENTRY(IThreadView)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IThreadView
public:
	STDMETHOD(get_ThreadID)(/*[out, retval]*/ long *pVal);
};

#endif //__FREETHREADED_H_
