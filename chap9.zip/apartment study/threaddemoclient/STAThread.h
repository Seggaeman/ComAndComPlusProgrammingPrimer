#if !defined(AFX_STATHREAD_H__5154AF22_3B16_11D3_998A_E0EC08C10000__INCLUDED_)
#define AFX_STATHREAD_H__5154AF22_3B16_11D3_998A_E0EC08C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// STAThread.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CSTAThread thread

class CSTAThread : public CWinThread
{
	DECLARE_DYNCREATE(CSTAThread)
protected:
	CSTAThread();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSTAThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSTAThread();

	// Generated message map functions
	//{{AFX_MSG(CSTAThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATHREAD_H__5154AF22_3B16_11D3_998A_E0EC08C10000__INCLUDED_)
