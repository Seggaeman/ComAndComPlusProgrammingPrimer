#if !defined(AFX_MTATHREAD_H__5154AF23_3B16_11D3_998A_E0EC08C10000__INCLUDED_)
#define AFX_MTATHREAD_H__5154AF23_3B16_11D3_998A_E0EC08C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MTAThread.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CMTAThread thread

class CMTAThread : public CWinThread
{
	DECLARE_DYNCREATE(CMTAThread)
protected:
	CMTAThread();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMTAThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMTAThread();

	// Generated message map functions
	//{{AFX_MSG(CMTAThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MTATHREAD_H__5154AF23_3B16_11D3_998A_E0EC08C10000__INCLUDED_)
