// MTAThread.cpp : implementation file
//

#include "stdafx.h"
#include "threaddemoclient.h"
#include "MTAThread.h"
#include "objectcreationdialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMTAThread

IMPLEMENT_DYNCREATE(CMTAThread, CWinThread)

CMTAThread::CMTAThread()
{
}

CMTAThread::~CMTAThread()
{
}

BOOL CMTAThread::InitInstance()
{
	CoInitializeEx(0,COINIT_MULTITHREADED);
	CObjectCreationDialog dlg;
	dlg.SetCaption("MTA");
	m_pMainWnd=&dlg;
	dlg.DoModal();
	return TRUE;
}

int CMTAThread::ExitInstance()
{
	CoUninitialize();
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CMTAThread, CWinThread)
	//{{AFX_MSG_MAP(CMTAThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMTAThread message handlers
