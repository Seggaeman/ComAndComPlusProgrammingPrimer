// STAThread.cpp : implementation file
//

#include "stdafx.h"
#include "threaddemoclient.h"
#include "STAThread.h"
#include "objectcreationdialog.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSTAThread

IMPLEMENT_DYNCREATE(CSTAThread, CWinThread)

CSTAThread::CSTAThread()
{
}

CSTAThread::~CSTAThread()
{
}

BOOL CSTAThread::InitInstance()
{
	CObjectCreationDialog dlg;
	CoInitializeEx(0,COINIT_APARTMENTTHREADED);
	dlg.SetCaption("STA");	
	m_pMainWnd=&dlg;
	dlg.DoModal();
	return TRUE;
}

int CSTAThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	CoUninitialize();
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CSTAThread, CWinThread)
	//{{AFX_MSG_MAP(CSTAThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSTAThread message handlers
