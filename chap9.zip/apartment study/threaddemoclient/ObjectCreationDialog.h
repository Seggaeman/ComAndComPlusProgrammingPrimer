#if !defined(AFX_OBJECTCREATIONDIALOG_H__5154AF21_3B16_11D3_998A_E0EC08C10000__INCLUDED_)
#define AFX_OBJECTCREATIONDIALOG_H__5154AF21_3B16_11D3_998A_E0EC08C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ObjectCreationDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CObjectCreationDialog dialog

class CObjectCreationDialog : public CDialog
{
// Construction
public:
	CObjectCreationDialog(CWnd* pParent = NULL);   // standard constructor
	void SetCaption(const char *caption);

// Dialog Data
	//{{AFX_DATA(CObjectCreationDialog)
	enum { IDD = IDD_DIALOG1 };
	CString	m_objectThreadID;
	CString	m_windowThreadID;
	int		m_objectType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjectCreationDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CObjectCreationDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnCreateObjectButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_caption;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBJECTCREATIONDIALOG_H__5154AF21_3B16_11D3_998A_E0EC08C10000__INCLUDED_)
