// ObjectCreationDialog.cpp : implementation file
//

#include "stdafx.h"
#include "threaddemoclient.h"
#include "ObjectCreationDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjectCreationDialog dialog


CObjectCreationDialog::CObjectCreationDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CObjectCreationDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CObjectCreationDialog)
	m_objectThreadID = _T("");
	m_windowThreadID = _T("");
	m_objectType = 1;
	//}}AFX_DATA_INIT
}

void CObjectCreationDialog::SetCaption(const char *caption)
{
	m_caption=caption;
}

void CObjectCreationDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjectCreationDialog)
	DDX_Text(pDX, IDC_OBJECT_THREAD_ID_STATIC, m_objectThreadID);
	DDX_Text(pDX, IDC_WINDOW_THREAD_ID_STATIC, m_windowThreadID);
	DDX_Radio(pDX, IDC_OBJECT_TYPE_RADIO, m_objectType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CObjectCreationDialog, CDialog)
	//{{AFX_MSG_MAP(CObjectCreationDialog)
	ON_BN_CLICKED(IDC_CREATE_OBJECT_BUTTON, OnCreateObjectButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CObjectCreationDialog message handlers

BOOL CObjectCreationDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetWindowText(m_caption);
	m_windowThreadID.Format("%ld",::GetCurrentThreadId());
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CObjectCreationDialog::OnCreateObjectButton() 
{
	HRESULT hRes;
	CString objectType;
	long threadID;
	IThreadViewPtr threadView;
	UpdateData(TRUE);
	switch (m_objectType)
	{
	case 0:
		objectType="threaddemo.singlethreaded";
		break;
	case 1:
		objectType="threaddemo.apartmentthreaded";
		break;
	case 2:
		objectType="threaddemo.freethreaded";
		break;
	case 3:
		objectType="threaddemo.boththreaded";
		break;
	case 4:
		objectType="threaddemo.neutralthreaded";
		break;
	default:
		ASSERT(FALSE);
	}
	hRes=threadView.CreateInstance(objectType);
	if (FAILED(hRes))
	{
		_com_error err(hRes);
		AfxMessageBox(err.ErrorMessage());
		return;
	}
	try {		
		threadView->get_ThreadID(&threadID);
		m_objectThreadID.Format("%ld",threadID);
		UpdateData(FALSE);
	}
	catch (_com_error err)
	{
		AfxMessageBox(err.ErrorMessage());
		return;
	}	
}
