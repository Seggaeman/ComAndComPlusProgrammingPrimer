#include "stdafx.h"
#include "resource.h"
#include "stockserverclientdlg.h"
#include "stockeventobj.h"
STDMETHODIMP CStockEvent::Invoke(DISPID dispID,REFIID riid,LCID lcid,
							WORD wFlags,DISPPARAMS* pDispParams,
							VARIANT* pVarResult,EXCEPINFO* pExcepInfo,
							UINT* puArgErr)
{
	HRESULT	hr = S_OK;
	BSTR ticker;
	float oldPrice;
	float newPrice;
	if	(pDispParams)
	{
		switch	(dispID)
		{
			// call PriceChange event
			case	1:
			{
				if	(pDispParams->cArgs == 3)
				{
					if	(pDispParams->rgvarg[2].vt == VT_BSTR && 
						 pDispParams->rgvarg[1].vt == VT_R4 &&
						 pDispParams->rgvarg[0].vt == VT_R4)
					{
						ticker=pDispParams->rgvarg[2].bstrVal;
						newPrice=pDispParams->rgvarg[1].fltVal;
						oldPrice=pDispParams->rgvarg[0].fltVal;
						PriceChange(ticker,newPrice,oldPrice);
					}
					else
						hr = DISP_E_TYPEMISMATCH;
				}
				else
					hr = DISP_E_BADPARAMCOUNT;

				break;
			}
			case	2:
			{
				// call MonitorInitiated event
				if	(pDispParams->cArgs == 2)
				{
					if	(pDispParams->rgvarg[0].vt == VT_R4 &&
						pDispParams->rgvarg[1].vt == VT_BSTR)
					{
						ticker=pDispParams->rgvarg[1].bstrVal;
						newPrice=pDispParams->rgvarg[0].fltVal;
						MonitorInitiated(ticker,newPrice);
					}	
					else
						hr = DISP_E_TYPEMISMATCH;
				}
				else
					hr = DISP_E_BADPARAMCOUNT;
				break;
			}		
			default:
			{
				hr = DISP_E_MEMBERNOTFOUND;
				break;
			}
		}
	}
	else
		hr = DISP_E_PARAMNOTFOUND;
	return	hr;
}

STDMETHODIMP CStockEvent::GetTypeInfoCount(UINT* pctinfo)
{
	return	E_NOTIMPL;
}

STDMETHODIMP CStockEvent::GetTypeInfo(UINT itinfo, LCID lcid,
									  ITypeInfo** pptinfo)
{
	return	E_NOTIMPL;
}

STDMETHODIMP CStockEvent::GetIDsOfNames(REFIID riid,
							LPOLESTR* rgszNames,UINT cNames, 
							LCID lcid, DISPID* rgdispid)
{
	return	E_NOTIMPL;
}

void CStockEvent::PriceChange(BSTR ticker,float newPrice,float oldPrice)
{
	CString strPrice;
	CString strTicker("Price Change! stock: ");
	strTicker+=ticker;		
	strPrice.Format(" new price=$%.2f old price=$%.2f",
		newPrice,oldPrice);
	m_pDlg->AddToEventList(strTicker+strPrice);
	return;
}	

void CStockEvent::MonitorInitiated(BSTR ticker,float currentPrice)
{
	CString strTicker("New stock added! ticker: ");
	strTicker+=ticker;
	AfxMessageBox(strTicker);
	return;
}