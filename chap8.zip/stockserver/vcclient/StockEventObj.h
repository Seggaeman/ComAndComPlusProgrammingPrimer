#ifndef STOCKSEVENT_H
#define STOCKSEVENT_H
#include <..\server\stockserver.h>		//midl generated code
class CStockserverclientDlg;
class CStockEvent : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatch
{
public:
	CStockEvent()
	{ }
	void SetClientDialog(CStockserverclientDlg* pDlg)
	{
		m_pDlg = pDlg;
	}
DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStockEvent)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_IID(DIID__IStockMonitorEvents, IDispatch)
END_COM_MAP()

public:	
	STDMETHOD(GetTypeInfoCount)(UINT* pctinfo);
	STDMETHOD(GetTypeInfo)(UINT itinfo,LCID lcid,ITypeInfo** pptinfo);
	STDMETHOD(GetIDsOfNames)(REFIID riid,LPOLESTR* rgszNames,
		UINT cNames,LCID lcid,DISPID* rgdispid);
	STDMETHOD(Invoke)(DISPID dispidMember,REFIID riid,LCID lcid,
		WORD wFlags,DISPPARAMS* pdispparams,VARIANT* pvarResult,
		EXCEPINFO* pexcepinfo, UINT* puArgErr);	
private:
	void PriceChange(BSTR ticker,float newPrice,float oldPrice);
	void MonitorInitiated(BSTR ticker,float currentPrice);
	CStockserverclientDlg *m_pDlg;
};
#endif //STOCKEVENT_H
