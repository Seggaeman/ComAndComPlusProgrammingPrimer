// StockMonitor.h : Declaration of the CStockMonitor

#ifndef __STOCKMONITOR_H_
#define __STOCKMONITOR_H_

#include "resource.h"       // main symbols
#include "stockserverCP.h"
#include <map>
#include <vector>
#include <time.h>
using namespace std;
/////////////////////////////////////////////////////////////////////////////
// CStockMonitor
DWORD WINAPI threadProc(void *pv);
class ATL_NO_VTABLE CStockMonitor : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CStockMonitor, &CLSID_StockMonitor>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CStockMonitor>,
	public IDispatchImpl<IStockMonitor, &IID_IStockMonitor, &LIBID_STOCKSERVERLib>,
	public CProxy_IStockMonitorEvents< CStockMonitor >
{
public:
	CStockMonitor()
	{
		DWORD threadID;		
		HANDLE hThreadHandle;
		srand( (unsigned)time( NULL ) );
		m_bHaltThread = false;
		AddNewStock(CComBSTR("MSFT"), 95, 67);
		AddNewStock(CComBSTR("NOC"), 57, 45);
		AddNewStock(CComBSTR("IBM"), 67, 55);
		AddNewStock(CComBSTR("COKE"), 78, 44);
		AddNewStock(CComBSTR("EMLX"), 190, 34);
		hThreadHandle=CreateThread(0,0,threadProc,this,0,&threadID);					
	}

DECLARE_REGISTRY_RESOURCEID(IDR_STOCKMONITOR)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStockMonitor)
	COM_INTERFACE_ENTRY(IStockMonitor)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CStockMonitor)
CONNECTION_POINT_ENTRY(DIID__IStockMonitorEvents)
END_CONNECTION_POINT_MAP()


// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IStockMonitor
public:
	STDMETHOD(AddNewStock)(/*[in]*/ BSTR ticker, /*[in]*/ float price, /*[in]*/ short propensityToRise);
	STDMETHOD(GetPrice)(/*[in]*/ BSTR ticker,/*[out,retval]*/ float *price);
	void MonitorStocks();
	void FinalRelease()
	{
		m_hEventShutdown = CreateEvent(NULL, false, false, NULL);
		m_bHaltThread=true;	
		WaitForSingleObject(m_hEventShutdown, INFINITE);
		m_StockPriceList.clear();
		m_StockPropensityList.clear();
		m_StockTickerList.clear();
	}
	bool m_bHaltThread;
	HANDLE m_hEventShutdown;	
private:
	map<CComBSTR,float> m_StockPriceList;
	map<CComBSTR,short> m_StockPropensityList;
	vector<CComBSTR> m_StockTickerList;
};

#endif //__STOCKMONITOR_H_
