// StockMonitor.cpp : Implementation of CStockMonitor
#include "stdafx.h"
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "Stockserver.h"
#include "StockMonitor.h"
/////////////////////////////////////////////////////////////////////////////
// CStockMonitor
const E_STOCKNOTFOUND=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+103);
const E_STOCKEXISTSALREADY=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+104);
DWORD WINAPI threadProc(void *pv)
{
	DWORD retval;
	CStockMonitor *stockMonitor;
	HRESULT hRes;
	hRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	if (SUCCEEDED(hRes))
	{
		stockMonitor=(CStockMonitor*)pv;
		while (!stockMonitor->m_bHaltThread)
		{
			stockMonitor->MonitorStocks();
			::Sleep(3000);
		}
		CoUninitialize();
		SetEvent(stockMonitor->m_hEventShutdown);
		retval=0;
	}
	else
		retval=2;
	return retval;
}

STDMETHODIMP CStockMonitor::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IStockMonitor
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

void CStockMonitor::MonitorStocks()
{
	map<CComBSTR,float>::iterator iter;
	short propensityValue, numStocks, randomNumber, index;
	CComBSTR ticker;
	float oldPrice, newPrice;
	ObjectLock lock(this);
	numStocks=m_StockPriceList.size();
	if (numStocks > 0)
	{
		randomNumber=rand();
		index=randomNumber % numStocks;
		ticker=m_StockTickerList[index];
		oldPrice=m_StockPriceList[ticker];
		propensityValue=m_StockPropensityList[ticker];
		if ((randomNumber % 100) < propensityValue)
			newPrice=oldPrice+4.0;
		else
		{
			if (oldPrice > 2.0)
				newPrice=oldPrice-2.0;
		}
		m_StockPriceList[ticker]=newPrice;
		Fire_PriceChange(ticker,newPrice,oldPrice);
	}
}

STDMETHODIMP CStockMonitor::GetPrice(BSTR ticker, float *price)
{
	map<CComBSTR,float>::iterator iter;
	ObjectLock lock(this);
	iter=m_StockPriceList.find(ticker);
	if (iter!=m_StockPriceList.end())
		*price=m_StockPriceList[ticker];
	else
	{
		*price=-1.0;
		return Error(_T("This stock does not exist"),IID_IStockMonitor,
			E_STOCKNOTFOUND);
	}
	return S_OK;
}

STDMETHODIMP CStockMonitor::AddNewStock(BSTR ticker, float price, short propensityToRise)
{
	map<CComBSTR,float>::iterator iter;
	ObjectLock lock(this);
	iter=m_StockPriceList.find(ticker);
	if (iter==m_StockPriceList.end())
	{
		m_StockPriceList[ticker]=price;
		m_StockPropensityList[ticker]=propensityToRise;
		m_StockTickerList.push_back(ticker);
		Fire_MonitorInitiated(ticker,price);
	}
	else
		return Error(_T("This stock exists already"),IID_IStockMonitor,
			E_STOCKEXISTSALREADY);
	return S_OK;
}
