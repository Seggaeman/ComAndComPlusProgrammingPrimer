// CDocumentChecker.cpp : Implementation of CCDocumentChecker
#include "stdafx.h"
#include "WritersComponent.h"
#include "CDocumentChecker.h"
#include <fstream>
const E_DICTIONARYFILENOTFOUND=MAKE_HRESULT(SEVERITY_ERROR,FACILITY_ITF,0x200+99);
/////////////////////////////////////////////////////////////////////////////
// CCDocumentChecker

STDMETHODIMP CCDocumentChecker::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISpellChecker,
		&IID_IGrammarChecker
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CCDocumentChecker::CheckSpelling(LPOLESTR word, VARIANT_BOOL *result)
{
	wstring str;
	vector< wstring >::iterator iter;
	*result=VARIANT_FALSE;
	for (iter=m_dictionary.begin();iter!=m_dictionary.end();iter++) {
		str=*iter;
		if (_wcsicmp(str.c_str(),word)==0) {
			*result=VARIANT_TRUE;
			break;
		}
	}
	return S_OK;
}

STDMETHODIMP CCDocumentChecker::UseCustomDictionary(LPOLESTR path)
{
	wstring str;
	char sz_path[255];
    wifstream dictionaryFile;    
	size_t bufsize;	
	bufsize=wcstombs(sz_path,path,255);
	if (bufsize==sizeof(sz_path) || bufsize == -1)
	{
		return Error(_T("Invalid or too long path specified"),IID_ISpellChecker,
			E_INVALIDARG);   
	}
	dictionaryFile.open(sz_path);
    if (!dictionaryFile.is_open()) 
	{
		return Error(_T("Dictionary file not found"),IID_ISpellChecker,
			E_DICTIONARYFILENOTFOUND);        
	}
    while (!dictionaryFile.eof()) 
	{
		dictionaryFile >> str;
		m_dictionary.push_back(str);
    }
    return S_OK;
}

STDMETHODIMP CCDocumentChecker::CheckGrammar(LPOLESTR sentence, VARIANT_BOOL *result)
{
	*result=VARIANT_FALSE;
     if (wcschr(sentence,',') && wcschr(sentence,'.'))
		*result=VARIANT_TRUE;
	
     return S_OK;
}
