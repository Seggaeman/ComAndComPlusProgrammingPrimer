// CDocumentChecker.h : Declaration of the CCDocumentChecker

#ifndef __CDOCUMENTCHECKER_H_
#define __CDOCUMENTCHECKER_H_

#include "resource.h"       // main symbols
#include <vector>
#include <string>
/////////////////////////////////////////////////////////////////////////////
// CCDocumentChecker
using namespace std;
class ATL_NO_VTABLE CCDocumentChecker : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCDocumentChecker, &CLSID_CDocumentChecker>,
	public ISupportErrorInfo,
	public ISpellChecker,
	public IGrammarChecker
{
public:
	CCDocumentChecker()
	{
		m_dictionary.push_back(OLESTR("Alan"));
		m_dictionary.push_back(OLESTR("Gordon"));
		m_dictionary.push_back(OLESTR("COM"));
		m_dictionary.push_back(OLESTR("ActiveX"));
		m_dictionary.push_back(OLESTR("OLE"));
		m_dictionary.push_back(OLESTR("COM+"));
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CDOCUMENTCHECKER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCDocumentChecker)
	COM_INTERFACE_ENTRY(ISpellChecker)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IGrammarChecker)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISpellChecker
public:
	STDMETHOD(CheckGrammar)(/*[in]*/ LPOLESTR, /*[out,retval]*/ VARIANT_BOOL *result);
	STDMETHOD(UseCustomDictionary)(/*[in]*/ LPOLESTR path);
	STDMETHOD(CheckSpelling)(/*[in]*/ LPOLESTR word,/*[out,retval]*/ VARIANT_BOOL *result);
private:
	vector<wstring> m_dictionary;
// IGrammarChecker
};

#endif //__CDOCUMENTCHECKER_H_
