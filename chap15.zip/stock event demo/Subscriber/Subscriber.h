
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Mon May 01 01:48:21 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter15\stock event demo\Subscriber\Subscriber.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Subscriber_h__
#define __Subscriber_h__

/* Forward Declarations */ 

#ifndef __IStockSubscriber_FWD_DEFINED__
#define __IStockSubscriber_FWD_DEFINED__
typedef interface IStockSubscriber IStockSubscriber;
#endif 	/* __IStockSubscriber_FWD_DEFINED__ */


#ifndef __StockSubscriber_FWD_DEFINED__
#define __StockSubscriber_FWD_DEFINED__

#ifdef __cplusplus
typedef class StockSubscriber StockSubscriber;
#else
typedef struct StockSubscriber StockSubscriber;
#endif /* __cplusplus */

#endif 	/* __StockSubscriber_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IStockSubscriber_INTERFACE_DEFINED__
#define __IStockSubscriber_INTERFACE_DEFINED__

/* interface IStockSubscriber */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStockSubscriber;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F98C3ED3-D28C-4F66-BF24-5674B29B86F9")
    IStockSubscriber : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IStockSubscriberVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStockSubscriber __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStockSubscriber __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStockSubscriber __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IStockSubscriber __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IStockSubscriber __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IStockSubscriber __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IStockSubscriber __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IStockSubscriberVtbl;

    interface IStockSubscriber
    {
        CONST_VTBL struct IStockSubscriberVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStockSubscriber_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStockSubscriber_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStockSubscriber_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStockSubscriber_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStockSubscriber_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStockSubscriber_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStockSubscriber_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IStockSubscriber_INTERFACE_DEFINED__ */



#ifndef __SUBSCRIBERLib_LIBRARY_DEFINED__
#define __SUBSCRIBERLib_LIBRARY_DEFINED__

/* library SUBSCRIBERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SUBSCRIBERLib;

EXTERN_C const CLSID CLSID_StockSubscriber;

#ifdef __cplusplus

class DECLSPEC_UUID("C2FAD43F-7A97-4815-8FF5-51B52AD8F7E9")
StockSubscriber;
#endif
#endif /* __SUBSCRIBERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


