// StockSubscriber.h : Declaration of the CStockSubscriber

#ifndef __STOCKSUBSCRIBER_H_
#define __STOCKSUBSCRIBER_H_

#include "resource.h"       // main symbols
#import "..\eventdemo\eventdemo.tlb"\
	raw_interfaces_only, raw_native_types, no_namespace, named_guids 

/////////////////////////////////////////////////////////////////////////////
// CStockSubscriber
using namespace Excel;
class ATL_NO_VTABLE CStockSubscriber : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CStockSubscriber, &CLSID_StockSubscriber>,
	public IDispatchImpl<IStockSubscriber, &IID_IStockSubscriber, 
		&LIBID_SUBSCRIBERLib>,
	public IDispatchImpl<IStockEvent, &IID_IStockEvent, 
		&LIBID_EVENTDEMOLib>
{
public:
	CStockSubscriber()
	{ }

DECLARE_REGISTRY_RESOURCEID(IDR_STOCKSUBSCRIBER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStockSubscriber)
	COM_INTERFACE_ENTRY(IStockSubscriber)
// DEL	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY2(IDispatch,IStockSubscriber)
	COM_INTERFACE_ENTRY(IStockEvent)
END_COM_MAP()

// IStockSubscriber
// IStockSubscriber
public:
// IStockEvent
	STDMETHOD(PriceChange)(BSTR ticker, FLOAT newPrice, FLOAT oldPrice)
	{ 
		SYSTEMTIME dtSysDateTime;
		SheetsPtr pSheets;
		_bstr_t strTicker(ticker);
		_WorkbookPtr pBook; 		
		_WorksheetPtr pSheet;
		_variant_t dtCurrent;		
		_variant_t var;
		_bstr_t strNumber;
		short i;
		if (ExcelIsRunning())
		{
			try
			{
				pExcel->put_Visible(LANG_USER_DEFAULT,VARIANT_TRUE);
				pBook=GetWorkBook();
				pSheets=pBook->Sheets;
				try 
				{
					pSheet=pSheets->Item[strTicker];
					pSheet->Activate();
				}
				catch(_com_error )
				{
					pSheet=pSheets->Add();
					pSheet->Name = strTicker;
					pSheet->Range[_bstr_t("A1")]->Value = "Ticker";
					pSheet->Range[_bstr_t("B1")]->Value = "New Price";
					pSheet->Range[_bstr_t("C1")]->Value = "Old Price";
					pSheet->Range[_bstr_t("D1")]->Value = "Time";
				}
				i=1;
				strNumber=i;
				var=pSheet->Range[_bstr_t("A")+strNumber]->Value;
				while (var.vt != VT_EMPTY)
				{	
					i++;
					strNumber=i;				
					var=pSheet->Range[_bstr_t("A")+strNumber]->Value;
				}
				GetLocalTime(&dtSysDateTime);
				dtCurrent.vt =VT_DATE;
				::SystemTimeToVariantTime(&dtSysDateTime,&(dtCurrent.date));	
				pSheet->Range[_bstr_t("A") + strNumber]->Value = ticker;
				pSheet->Range[_bstr_t("B") + strNumber]->Value = newPrice;
				pSheet->Range[_bstr_t("C") + strNumber]->Value = oldPrice;
				pSheet->Range[_bstr_t("D") + strNumber]->Value = dtCurrent;
				pSheet->Columns->AutoFit();
			}
			catch (_com_error err) 
			{
				// Do nothing for now
			}
		}
		return S_OK;
	}
	STDMETHOD(NewStockListed)(BSTR ticker, FLOAT price)
	{
		return E_NOTIMPL;
	}
private:
	_WorkbookPtr GetWorkBook();
	BOOL ExcelIsRunning();
	_ApplicationPtr pExcel;
};

#endif //__STOCKSUBSCRIBER_H_
