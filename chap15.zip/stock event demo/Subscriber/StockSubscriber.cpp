// StockSubscriber.cpp : Implementation of CStockSubscriber
#include "stdafx.h"
#include "Subscriber.h"
#include "StockSubscriber.h"
#include "getpathfromreg.h"
/////////////////////////////////////////////////////////////////////////////
// CStockSubscriber

BOOL CStockSubscriber::ExcelIsRunning()
{
	HRESULT hRes;
	hRes=pExcel.GetActiveObject("Excel.Application");
	if (S_OK==hRes)
		return TRUE;
	else
		return FALSE;
}

_WorkbookPtr CStockSubscriber::GetWorkBook()
{
	_variant_t blank(DISP_E_PARAMNOTFOUND, VT_ERROR);
	long i, intNumBooks;
	WorkbooksPtr pBooks;
	_WorkbookPtr pBook; 
	SYSTEMTIME dtSysDateTime;
	char lpFileName[255];
	_bstr_t strFileName;
	_bstr_t strFullPath;
	 
	pBooks=pExcel->Workbooks;
	intNumBooks=pBooks->Count;	
	GetLocalTime(&dtSysDateTime);
	sprintf(lpFileName,"stock%d%d%d.xls", dtSysDateTime.wMonth,dtSysDateTime.wDay,dtSysDateTime.wYear);	
	strFileName=lpFileName;
	strFullPath=GetPathFromReg(_T("OutputDir"))+_bstr_t("\\") + strFileName;

	for (i=1;i<=intNumBooks;i++)
	{
		pBook=pBooks->Item[_variant_t(i)];
		if (pBook->Name==strFileName)
			break;
	}
	if (NULL==pBook)
	{
		try {
			pBook=pBooks->Open(strFullPath);
		}
		catch ( _com_error )
		{
			pBook=pBooks->Add();
			pBook->SaveAs(strFullPath,blank,blank,blank,blank,blank,xlExclusive);
		}
	}
	return pBook;
}
