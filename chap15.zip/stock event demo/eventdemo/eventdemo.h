
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0279 */
/* at Mon May 01 01:38:48 2000
 */
/* Compiler settings for C:\Alan\books\vcppbook\readydemos\chapter15\stock event demo\eventdemo\eventdemo.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __eventdemo_h__
#define __eventdemo_h__

/* Forward Declarations */ 

#ifndef __IStockEvent_FWD_DEFINED__
#define __IStockEvent_FWD_DEFINED__
typedef interface IStockEvent IStockEvent;
#endif 	/* __IStockEvent_FWD_DEFINED__ */


#ifndef __StockEvent_FWD_DEFINED__
#define __StockEvent_FWD_DEFINED__

#ifdef __cplusplus
typedef class StockEvent StockEvent;
#else
typedef struct StockEvent StockEvent;
#endif /* __cplusplus */

#endif 	/* __StockEvent_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IStockEvent_INTERFACE_DEFINED__
#define __IStockEvent_INTERFACE_DEFINED__

/* interface IStockEvent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStockEvent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FA6BAACB-91D3-4547-A2B1-4A9682353DAC")
    IStockEvent : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE PriceChange( 
            /* [in] */ BSTR ticker,
            /* [in] */ float newPrice,
            /* [in] */ float oldPrice) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE NewStockListed( 
            /* [in] */ BSTR ticker,
            /* [in] */ float price) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStockEventVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStockEvent __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStockEvent __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IStockEvent __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PriceChange )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ BSTR ticker,
            /* [in] */ float newPrice,
            /* [in] */ float oldPrice);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NewStockListed )( 
            IStockEvent __RPC_FAR * This,
            /* [in] */ BSTR ticker,
            /* [in] */ float price);
        
        END_INTERFACE
    } IStockEventVtbl;

    interface IStockEvent
    {
        CONST_VTBL struct IStockEventVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStockEvent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStockEvent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStockEvent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStockEvent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStockEvent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStockEvent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStockEvent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IStockEvent_PriceChange(This,ticker,newPrice,oldPrice)	\
    (This)->lpVtbl -> PriceChange(This,ticker,newPrice,oldPrice)

#define IStockEvent_NewStockListed(This,ticker,price)	\
    (This)->lpVtbl -> NewStockListed(This,ticker,price)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStockEvent_PriceChange_Proxy( 
    IStockEvent __RPC_FAR * This,
    /* [in] */ BSTR ticker,
    /* [in] */ float newPrice,
    /* [in] */ float oldPrice);


void __RPC_STUB IStockEvent_PriceChange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStockEvent_NewStockListed_Proxy( 
    IStockEvent __RPC_FAR * This,
    /* [in] */ BSTR ticker,
    /* [in] */ float price);


void __RPC_STUB IStockEvent_NewStockListed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStockEvent_INTERFACE_DEFINED__ */



#ifndef __EVENTDEMOLib_LIBRARY_DEFINED__
#define __EVENTDEMOLib_LIBRARY_DEFINED__

/* library EVENTDEMOLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_EVENTDEMOLib;

EXTERN_C const CLSID CLSID_StockEvent;

#ifdef __cplusplus

class DECLSPEC_UUID("8796E0F6-552D-4E50-8146-EB69296065B6")
StockEvent;
#endif
#endif /* __EVENTDEMOLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


