// StockEvent.cpp : Implementation of CStockEvent
#include "stdafx.h"
#include "Eventdemo.h"
#include "StockEvent.h"

/////////////////////////////////////////////////////////////////////////////
// CStockEvent


STDMETHODIMP CStockEvent::PriceChange(BSTR ticker, float newPrice, float oldPrice)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CStockEvent::NewStockListed(BSTR ticker, float price)
{
	// TODO: Add your implementation code here

	return S_OK;
}
