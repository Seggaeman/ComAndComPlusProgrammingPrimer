// StockEvent.h : Declaration of the CStockEvent

#ifndef __STOCKEVENT_H_
#define __STOCKEVENT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CStockEvent
class ATL_NO_VTABLE CStockEvent : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CStockEvent, &CLSID_StockEvent>,
	public IDispatchImpl<IStockEvent, &IID_IStockEvent, &LIBID_EVENTDEMOLib>
{
public:
	CStockEvent()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_STOCKEVENT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CStockEvent)
	COM_INTERFACE_ENTRY(IStockEvent)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IStockEvent
public:
	STDMETHOD(NewStockListed)(/*[in]*/ BSTR ticker,/*[in]*/ float price);
	STDMETHOD(PriceChange)(/*[in]*/ BSTR ticker,/*[in]*/ float newPrice,/*[in]*/ float oldPrice);
};

#endif //__STOCKEVENT_H_
