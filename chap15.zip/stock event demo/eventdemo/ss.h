Option Explicit
Private objEventClass As EVENTDEMOLib.StockEvent
Private objStockList As Dictionary
Private objStockPropensityList As Dictionary

Private Sub cmdSendEvent_Click()    
    Call objEventClass.PriceChange("MSFT", 45, 55)
End Sub

Private Sub cmdStartEvents_Click()
    tmStockEvents.Enabled = True
End Sub

Private Sub cmdStopEvents_Click()
    tmStockEvents.Enabled = False
End Sub

Private Sub Form_Load()
    On Error GoTo errHandler
    tmStockEvents.Enabled = False
    Set objEventClass = New EVENTDEMOLib.StockEvent
    Set objStockList = New Dictionary
    Set objStockPropensityList = New Dictionary
    Call LoadStockList
    Call Randomize
    Exit Sub
errHandler:
    Call MsgBox(Err.Description)
End Sub

Private Function PickAStock(ByRef sngNewStockPrice As Single, ByRef sngOldStockPrice As Single) As String
    Dim intStockPropensity As Integer
    Dim intRandomPropensity As Integer
    Dim sngRandomNumber As Single
    Dim numStocks As Integer
    Dim index As Integer
    Dim strTicker As String
    numStocks = objStockList.Count
    sngRandomNumber = Rnd * 1000
    index = sngRandomNumber Mod numStocks
    strTicker = objStockList.Keys(index)
    sngOldStockPrice = objStockList.Item(strTicker)
    intStockPropensity = objStockPropensityList.Item(strTicker)
    intRandomPropensity = sngRandomNumber Mod 100
    If intRandomPropensity < intStockPropensity Then
        sngNewStockPrice = sngOldStockPrice + 4
    Else
        If sngOldStockPrice > 2 Then
            sngNewStockPrice = sngOldStockPrice - 2
        End If
    End If
    objStockList.Item(strTicker) = sngNewStockPrice
    PickAStock = strTicker
End Function

Private Sub LoadStockList()
    Call AddNewStock("MSFT", 95, 67)
    Call AddNewStock("NOC", 57, 45)
    Call AddNewStock("IBM", 67, 55)
    Call AddNewStock("COKE", 78, 44)
    Call AddNewStock("EMLX", 190, 34)
End Sub
Private Function GetPrice(ByVal strTicker As String) As Single
    GetPrice = objStockList.Item(strTicker)
End Function
Private Function GetPropensity(ByVal strTicker As String) As Integer
    GetPropensity = objStockPropensityList.Item(strTicker)
End Function
Private Sub AddNewStock(ByVal strTicker As String, ByVal price As Single, _
                        ByVal propensityToRise As Integer)
    On Error GoTo errHandler
    Call objStockList.Add(strTicker, price)
    Call objStockPropensityList.Add(strTicker, propensityToRise)
    Exit Sub
errHandler:
    Call MsgBox(Err.Description)
End Sub

Private Sub tmStockEvents_Timer()
    On Error GoTo errHandler
    Dim strTicker As String
    Dim sngNewPrice As Single
    Dim sngOldPrice As Single
    strTicker = PickAStock(sngNewPrice, sngOldPrice)
    Call objEventClass.PriceChange(strTicker, sngNewPrice, sngOldPrice)
    txtEventList.Text = txtEventList.Text & vbCrLf & _
            "Stock = " & strTicker & " Price = " & sngNewPrice
    Exit Sub
errHandler:
    Call MsgBox(Err.Description)
End Sub
